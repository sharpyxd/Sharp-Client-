package com.sharpmacro.client;

import com.sharpmacro.client.gui.ModulesScreen;
import com.sharpmacro.client.modules.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class SharpMacroClient implements ClientModInitializer {

    /** Keybind: press P to open the Modules GUI. */
    public static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {

        // ── Register P keybind ────────────────────────────────────────────
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.sharp-macro.open_gui",          // translation key
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_P,                     // default: P
            "category.sharp-macro"               // category shown in Controls screen
        ));

        // ── Tick event ────────────────────────────────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            // Open GUI when keybind is pressed
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ModulesScreen(null));
                }
            }

            // Tick all enabled modules
            ModuleManager.getInstance().tick();
        });
    }
}
