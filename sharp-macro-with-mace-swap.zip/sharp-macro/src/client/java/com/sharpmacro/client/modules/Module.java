package com.sharpmacro.client.modules;

import java.util.LinkedHashMap;
import java.util.Map;

public abstract class Module {

    private final String name;
    private final String description;
    private boolean enabled = false;

    // Settings stored as key -> Setting<?>
    protected final Map<String, Setting<?>> settings = new LinkedHashMap<>();

    public Module(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public boolean isEnabled()     { return enabled; }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (enabled) onEnable();
        else         onDisable();
    }

    public void toggle() { setEnabled(!enabled); }

    public Map<String, Setting<?>> getSettings() { return settings; }

    /** Called every client tick while enabled. */
    public void onTick() {}

    protected void onEnable()  {}
    protected void onDisable() {}

    // ─── Inner Setting class ───────────────────────────────────────────────

    public static class Setting<T> {
        private final String name;
        private T value;
        private final T min;   // null for non-numeric
        private final T max;

        public Setting(String name, T defaultValue) {
            this(name, defaultValue, null, null);
        }

        public Setting(String name, T defaultValue, T min, T max) {
            this.name  = name;
            this.value = defaultValue;
            this.min   = min;
            this.max   = max;
        }

        public String getName()  { return name; }
        public T      getValue() { return value; }
        public T      getMin()   { return min; }
        public T      getMax()   { return max; }

        @SuppressWarnings("unchecked")
        public void setValue(T val) {
            if (min != null && val instanceof Comparable) {
                Comparable<T> cVal = (Comparable<T>) val;
                if (cVal.compareTo(min) < 0) val = min;
                if (cVal.compareTo(max) > 0) val = max;
            }
            this.value = val;
        }

        public boolean isBoolean() { return value instanceof Boolean; }
        public boolean isNumber()  { return value instanceof Number; }
    }
}
