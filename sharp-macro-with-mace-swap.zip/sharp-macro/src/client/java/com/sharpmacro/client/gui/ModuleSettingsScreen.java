package com.sharpmacro.client.gui;

import com.sharpmacro.client.modules.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * ModuleSettingsScreen
 *
 * Shows all settings for a single module:
 *   • Boolean settings  → toggle button
 *   • Numeric settings  → vanilla-style slider
 *
 * Style matches ModulesScreen (title, background, Done button).
 */
public class ModuleSettingsScreen extends Screen {

    private static final int TITLE_Y        = 15;
    private static final int SUBTITLE_Y     = 27;
    private static final int FIRST_ROW_Y    = 45;
    private static final int ROW_HEIGHT     = 24;
    private static final int WIDGET_WIDTH   = 200;
    private static final int WIDGET_HEIGHT  = 20;

    private final Screen parent;
    private final Module module;

    public ModuleSettingsScreen(Screen parent, Module module) {
        super(Text.literal(module.getName() + " – Settings"));
        this.parent = parent;
        this.module = module;
    }

    @Override
    protected void init() {
        Map<String, Module.Setting<?>> settingsMap = module.getSettings();
        List<Module.Setting<?>> settingsList = new ArrayList<>(settingsMap.values());

        int centerX = this.width / 2;

        for (int i = 0; i < settingsList.size(); i++) {
            Module.Setting<?> setting = settingsList.get(i);
            int y = FIRST_ROW_Y + i * ROW_HEIGHT;
            int x = centerX - WIDGET_WIDTH / 2;

            if (setting.isBoolean()) {
                // Cast is safe because isBoolean() verified the type
                @SuppressWarnings("unchecked")
                Module.Setting<Boolean> boolSetting = (Module.Setting<Boolean>) setting;

                addDrawableChild(
                    ButtonWidget.builder(
                        buildBoolText(boolSetting),
                        btn -> {
                            boolSetting.setValue(!boolSetting.getValue());
                            btn.setMessage(buildBoolText(boolSetting));
                        }
                    )
                    .dimensions(x, y, WIDGET_WIDTH, WIDGET_HEIGHT)
                    .build()
                );

            } else if (setting.isNumber()) {
                // Numeric → slider
                @SuppressWarnings("unchecked")
                Module.Setting<Float> floatSetting = (Module.Setting<Float>) setting;

                float min   = floatSetting.getMin()   != null ? floatSetting.getMin()   : 0f;
                float max   = floatSetting.getMax()   != null ? floatSetting.getMax()   : 100f;
                float value = floatSetting.getValue();

                double ratio = (double)(value - min) / (max - min);

                addDrawableChild(new SliderWidget(x, y, WIDGET_WIDTH, WIDGET_HEIGHT,
                    buildSliderText(floatSetting), ratio) {

                    @Override
                    protected void updateMessage() {
                        setMessage(buildSliderText(floatSetting));
                    }

                    @Override
                    protected void applyValue() {
                        float newVal = min + (float)(this.value * (max - min));
                        // Round to 1 decimal
                        newVal = Math.round(newVal * 10f) / 10f;
                        floatSetting.setValue(newVal);
                    }
                });
            }
        }

        // Done button
        int doneY = Math.max(
            FIRST_ROW_Y + settingsList.size() * ROW_HEIGHT + 8,
            this.height - 30
        );
        addDrawableChild(
            ButtonWidget.builder(
                Text.translatable("gui.done"),
                btn -> this.client.setScreen(parent)
            )
            .dimensions(centerX - 100, doneY, 200, WIDGET_HEIGHT)
            .build()
        );
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        // Title
        context.drawCenteredTextWithShadow(
            this.textRenderer, this.title, this.width / 2, TITLE_Y, 0xFFFFFF);
        // Subtitle – module description
        context.drawCenteredTextWithShadow(
            this.textRenderer,
            Text.literal("§7" + module.getDescription()),
            this.width / 2, SUBTITLE_Y, 0xFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }

    // ─── Helpers ─────────────────────────────────────────────────────────

    private static Text buildBoolText(Module.Setting<Boolean> s) {
        String state = s.getValue() ? "§aEnabled" : "§cDisabled";
        return Text.literal(s.getName() + ": " + state);
    }

    private static Text buildSliderText(Module.Setting<Float> s) {
        return Text.literal(s.getName() + ": " + String.format("%.1f", s.getValue()));
    }
}
