package com.sharpmacro.client.gui;

import com.sharpmacro.client.modules.Module;
import com.sharpmacro.client.modules.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

/**
 * ModulesScreen
 *
 * A Minecraft-style GUI that lists every module with:
 *   • A toggle button  (green = ON, red = OFF)
 *   • A "Settings" button that opens ModuleSettingsScreen
 *
 * Layout mirrors vanilla option screens (title at top, rows of widgets,
 * Done button at the bottom).
 */
public class ModulesScreen extends Screen {

    private static final int TITLE_Y          = 15;
    private static final int ROW_HEIGHT       = 24;
    private static final int FIRST_ROW_Y      = 40;
    private static final int TOGGLE_WIDTH     = 120;
    private static final int SETTINGS_WIDTH   = 80;
    private static final int BUTTON_HEIGHT    = 20;
    private static final int GAP              = 4;

    /** The screen that was open before this one (so we can return to it). */
    private final Screen parent;

    public ModulesScreen(Screen parent) {
        super(Text.literal("Sharp Macro – Modules"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        List<Module> modules = ModuleManager.getInstance().getModules();

        int totalWidth  = TOGGLE_WIDTH + GAP + SETTINGS_WIDTH;
        int startX      = (this.width  - totalWidth) / 2;

        for (int i = 0; i < modules.size(); i++) {
            Module module = modules.get(i);
            int y = FIRST_ROW_Y + i * ROW_HEIGHT;

            // Toggle button
            addDrawableChild(
                ButtonWidget.builder(
                    buildToggleText(module),
                    btn -> {
                        module.toggle();
                        btn.setMessage(buildToggleText(module));
                    }
                )
                .dimensions(startX, y, TOGGLE_WIDTH, BUTTON_HEIGHT)
                .build()
            );

            // Settings button
            addDrawableChild(
                ButtonWidget.builder(
                    Text.literal("Settings"),
                    btn -> this.client.setScreen(new ModuleSettingsScreen(this, module))
                )
                .dimensions(startX + TOGGLE_WIDTH + GAP, y, SETTINGS_WIDTH, BUTTON_HEIGHT)
                .build()
            );
        }

        // Done button – bottom center, like all vanilla screens
        int doneY = Math.max(
            FIRST_ROW_Y + modules.size() * ROW_HEIGHT + 8,
            this.height - 30
        );
        addDrawableChild(
            ButtonWidget.builder(
                Text.translatable("gui.done"),
                btn -> this.client.setScreen(parent)
            )
            .dimensions(this.width / 2 - 100, doneY, 200, BUTTON_HEIGHT)
            .build()
        );
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Vanilla dark dirt background
        this.renderBackground(context, mouseX, mouseY, delta);
        // Title
        context.drawCenteredTextWithShadow(
            this.textRenderer,
            this.title,
            this.width / 2,
            TITLE_Y,
            0xFFFFFF
        );
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false; // Keep the game running while the GUI is open
    }

    // ─── Helpers ─────────────────────────────────────────────────────────

    private static Text buildToggleText(Module module) {
        String status = module.isEnabled()
            ? "§a[ON]  " + module.getName()
            : "§c[OFF] " + module.getName();
        return Text.literal(status);
    }
}
