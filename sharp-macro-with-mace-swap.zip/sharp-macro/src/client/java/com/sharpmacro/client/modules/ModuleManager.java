package com.sharpmacro.client.modules;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    private static ModuleManager instance;

    private final List<Module> modules = new ArrayList<>();

    private ModuleManager() {
        // Register all modules here
        register(new AutoMaceSwapModule());
    }

    public static ModuleManager getInstance() {
        if (instance == null) instance = new ModuleManager();
        return instance;
    }

    private void register(Module m) {
        modules.add(m);
    }

    public List<Module> getModules() {
        return modules;
    }

    /** Called every client tick – ticks all enabled modules. */
    public void tick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }
}
