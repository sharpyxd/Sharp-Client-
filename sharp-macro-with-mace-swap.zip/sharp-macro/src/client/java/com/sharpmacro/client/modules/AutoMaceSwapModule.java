package com.sharpmacro.client.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * AutoMaceSwap
 *
 * While the player is falling, once their fall distance reaches the configured
 * threshold (default 2.8 blocks) the module instantly switches to a Mace in
 * their hotbar.  After the next attack hit the previous slot is restored.
 *
 * Settings
 *  - Fall Threshold  (float, 2.0 – 10.0, default 2.8)
 *  - Swap Back       (boolean, default true)
 *  - Only On Ground  (boolean, default false)  – swap back only after landing
 */
public class AutoMaceSwapModule extends Module {

    // ─── Settings ─────────────────────────────────────────────────────────

    private final Setting<Float>   fallThreshold;
    private final Setting<Boolean> swapBack;
    private final Setting<Boolean> onlyOnGround;

    // ─── Internal state ───────────────────────────────────────────────────

    /** The hotbar slot that was active before we swapped to the mace. */
    private int  previousSlot     = -1;
    /** Whether we are currently holding the mace because of this module. */
    private boolean swappedToMace = false;
    /** Track whether the player was attacking last tick (edge detection). */
    private boolean wasAttacking  = false;

    public AutoMaceSwapModule() {
        super("Auto Mace Swap",
              "Automatically swaps to a Mace when falling and swaps back after hitting.");

        fallThreshold = new Setting<>("Fall Threshold", 2.8f, 0.5f, 20.0f);
        swapBack      = new Setting<>("Swap Back",      true);
        onlyOnGround  = new Setting<>("Only On Ground", false);

        settings.put(fallThreshold.getName(), fallThreshold);
        settings.put(swapBack.getName(),      swapBack);
        settings.put(onlyOnGround.getName(),  onlyOnGround);
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────

    @Override
    protected void onDisable() {
        // Restore slot when module is turned off mid-air
        if (swappedToMace) restorePreviousSlot();
    }

    // ─── Tick logic ───────────────────────────────────────────────────────

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        float fallDist  = mc.player.fallDistance;
        boolean falling = !mc.player.isOnGround() && mc.player.getVelocity().y < 0;

        // ── 1. Swap TO mace when threshold is reached ────────────────────
        if (!swappedToMace && falling && fallDist >= fallThreshold.getValue()) {
            int maceSlot = findMaceInHotbar(mc);
            if (maceSlot != -1 && mc.player.getInventory().selectedSlot != maceSlot) {
                previousSlot  = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = maceSlot;
                swappedToMace = true;
            }
        }

        // ── 2. Detect attack & swap BACK ─────────────────────────────────
        if (swappedToMace && swapBack.getValue()) {
            boolean attacking = mc.options.attackKey.isPressed();

            boolean shouldSwapBack = false;

            if (onlyOnGround.getValue()) {
                // Swap back once the player lands (on ground)
                if (mc.player.isOnGround()) shouldSwapBack = true;
            } else {
                // Swap back on the leading edge of the attack key press
                if (attacking && !wasAttacking) shouldSwapBack = true;
                // Also swap back if they land without attacking
                if (mc.player.isOnGround() && !falling) shouldSwapBack = true;
            }

            if (shouldSwapBack) restorePreviousSlot();
        }

        // ── 3. Safety: if player is on the ground and still "swapped", revert
        if (swappedToMace && mc.player.isOnGround()) {
            restorePreviousSlot();
        }

        wasAttacking = mc.options.attackKey.isPressed();
    }

    // ─── Helpers ──────────────────────────────────────────────────────────

    /**
     * Returns the first hotbar slot (0-8) containing a Mace, or -1 if none.
     */
    private int findMaceInHotbar(MinecraftClient mc) {
        PlayerInventory inv = mc.player.getInventory();
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = inv.getStack(slot);
            if (!stack.isEmpty() && stack.getItem() == Items.MACE) {
                return slot;
            }
        }
        return -1;
    }

    private void restorePreviousSlot() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (previousSlot >= 0 && previousSlot <= 8) {
            mc.player.getInventory().selectedSlot = previousSlot;
        }
        previousSlot  = -1;
        swappedToMace = false;
    }
}
