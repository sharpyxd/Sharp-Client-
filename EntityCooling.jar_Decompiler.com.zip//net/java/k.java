package net.java;

public class k {
   private static byte[] a;
   private static byte[] b;
   private static byte[] c;
   private static byte[] d;
   private static byte[] e;
   private static byte[] f;
   private static byte[] g;
   private static byte[] h;

   public static byte[] a() {
      if (b == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('d');
         var0.append('y');
         var0.append('l');
         var0.append('i');
         var0.append('b');
         var0.append('_');
         var0.append('a');
         var0.append('a');
         var0.append('r');
         var0.append('c');
         var0.append('h');
         var0.append('6');
         var0.append('4');
         b = a(var0.toString());
      }

      return b;
   }

   public static byte[] b() {
      if (a == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('d');
         var0.append('y');
         var0.append('l');
         var0.append('i');
         var0.append('b');
         var0.append('_');
         var0.append('x');
         var0.append('8');
         var0.append('6');
         var0.append('_');
         var0.append('6');
         var0.append('4');
         a = a(var0.toString());
      }

      return a;
   }

   public static byte[] c() {
      if (c == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('s');
         var0.append('o');
         var0.append('_');
         var0.append('x');
         var0.append('8');
         var0.append('6');
         var0.append('_');
         var0.append('6');
         var0.append('4');
         c = a(var0.toString());
      }

      return c;
   }

   public static byte[] d() {
      if (d == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('s');
         var0.append('o');
         var0.append('_');
         var0.append('i');
         var0.append('3');
         var0.append('8');
         var0.append('6');
         d = a(var0.toString());
      }

      return d;
   }

   public static byte[] e() {
      if (d == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('s');
         var0.append('o');
         var0.append('_');
         var0.append('a');
         var0.append('a');
         var0.append('r');
         var0.append('c');
         var0.append('h');
         var0.append('6');
         var0.append('4');
         d = a(var0.toString());
      }

      return d;
   }

   public static byte[] f() {
      if (e == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('d');
         var0.append('l');
         var0.append('l');
         var0.append('_');
         var0.append('i');
         var0.append('3');
         var0.append('8');
         var0.append('6');
         e = a(var0.toString());
      }

      return e;
   }

   public static byte[] g() {
      if (f == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('d');
         var0.append('l');
         var0.append('l');
         var0.append('_');
         var0.append('x');
         var0.append('8');
         var0.append('6');
         var0.append('_');
         var0.append('6');
         var0.append('4');
         f = a(var0.toString());
      }

      return f;
   }

   public static byte[] h() {
      if (g == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('d');
         var0.append('l');
         var0.append('l');
         var0.append('_');
         var0.append('a');
         var0.append('a');
         var0.append('r');
         var0.append('c');
         var0.append('h');
         var0.append('6');
         var0.append('4');
         g = a(var0.toString());
      }

      return g;
   }

   private static byte[] a(String param0) {
      // $FF: Couldn't be decompiled
   }
}
