package me.ytdarkguy.shadesmp;

import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class DropSoulCommand implements CommandExecutor, Listener {
   private final ShadeSMP plugin;
   private final NamespacedKey soulKey;

   public DropSoulCommand(ShadeSMP plugin) {
      this.plugin = plugin;
      this.soulKey = new NamespacedKey(plugin, "bottled_soul");
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         PlayerSoul current = this.plugin.getSoulManager().getSoul(player);
         ItemStack bottle = this.createBottle(current);
         if (player.getInventory().firstEmpty() == -1) {
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize("&cNot enough inventory space"));
            return true;
         } else {
            player.getInventory().addItem(new ItemStack[]{bottle});
            this.plugin.getSoulManager().setSoul(player, PlayerSoul.SOULLESS);
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize("&7Bottled your " + formatSoulName(current)));
            return true;
         }
      } else {
         return true;
      }
   }

   @EventHandler
   public void onRightClick(PlayerInteractEvent event) {
      if (event.getHand() == EquipmentSlot.HAND) {
         Action action = event.getAction();
         if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            Player player = event.getPlayer();
            ItemStack held = player.getInventory().getItemInMainHand();
            if (this.isBottle(held)) {
               event.setCancelled(true);
               PlayerSoul bottled = this.getSoulFromBottle(held);
               if (bottled != null) {
                  PlayerSoul current = this.plugin.getSoulManager().getSoul(player);
                  this.plugin.getSoulManager().setSoul(player, bottled);
                  if (current == PlayerSoul.SOULLESS) {
                     held.setAmount(0);
                  } else {
                     ItemStack newBottle = this.createBottle(current);
                     player.getInventory().setItemInMainHand(newBottle);
                  }

               }
            }
         }
      }
   }

   public ItemStack createBottle(PlayerSoul soul) {
      ItemStack item = new ItemStack(Material.NETHER_STAR);
      ItemMeta meta = item.getItemMeta();
      meta.displayName(Component.text("§fBottled Soul").decoration(TextDecoration.ITALIC, false));
      meta.lore(List.of((TextComponent)Component.text(formatSoulName(soul), soul.getColor()).decoration(TextDecoration.ITALIC, false)));
      meta.addEnchant(Enchantment.UNBREAKING, 1, true);
      meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES});
      meta.getPersistentDataContainer().set(this.soulKey, PersistentDataType.STRING, soul.key());
      item.setItemMeta(meta);
      return item;
   }

   private static String formatSoulName(PlayerSoul soul) {
      String raw = soul.key().replace("_", " ").toLowerCase();
      char var10000 = Character.toUpperCase(raw.charAt(0));
      return var10000 + raw.substring(1);
   }

   public boolean isBottle(ItemStack item) {
      if (item != null && item.getType() == Material.NETHER_STAR) {
         return !item.hasItemMeta() ? false : item.getItemMeta().getPersistentDataContainer().has(this.soulKey, PersistentDataType.STRING);
      } else {
         return false;
      }
   }

   public PlayerSoul getSoulFromBottle(ItemStack item) {
      String key = (String)item.getItemMeta().getPersistentDataContainer().get(this.soulKey, PersistentDataType.STRING);
      return key == null ? null : PlayerSoul.fromKey(key);
   }
}
