package me.ytdarkguy.shadesmp;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class ShadeSMP extends JavaPlugin {
   private static ShadeSMP instance;
   private SoullessBladeListener soullessBladeListener;
   private SoulManager soulManager;
   private SoulActionBarManager soulActionBarManager;
   private VenomSoulListener venomSoulListener;
   private QuickeningSoulListener quickeningSoulListener;
   private ColdSoulListener coldSoulListener;
   private DarkSoulListener darkSoulListener;
   private SharpSoulListener sharpSoulListener;
   private FlamingSoulListener flamingSoulListener;
   private SoullessSoulListener soullessSoulListener;
   private SoulTickTask soulTickTask;
   private GracePeriodManager gracePeriodManager;
   private TargetModeManager targetModeManager;

   public void onEnable() {
      instance = this;
      this.soulManager = new SoulManager(this);
      this.getServer().getPluginManager().registerEvents(this.soulManager, this);
      this.soulActionBarManager = new SoulActionBarManager(this);
      this.venomSoulListener = new VenomSoulListener(this);
      this.getServer().getPluginManager().registerEvents(this.venomSoulListener, this);
      this.quickeningSoulListener = new QuickeningSoulListener(this);
      this.getServer().getPluginManager().registerEvents(this.quickeningSoulListener, this);
      this.coldSoulListener = new ColdSoulListener(this);
      this.getServer().getPluginManager().registerEvents(this.coldSoulListener, this);
      this.darkSoulListener = new DarkSoulListener(this);
      this.getServer().getPluginManager().registerEvents(this.darkSoulListener, this);
      this.sharpSoulListener = new SharpSoulListener(this);
      this.getServer().getPluginManager().registerEvents(this.sharpSoulListener, this);
      this.flamingSoulListener = new FlamingSoulListener(this);
      this.getServer().getPluginManager().registerEvents(this.flamingSoulListener, this);
      this.soullessSoulListener = new SoullessSoulListener(this);
      this.getServer().getPluginManager().registerEvents(this.soullessSoulListener, this);
      this.soulTickTask = new SoulTickTask(this);
      this.soulTickTask.start();
      this.getServer().getPluginManager().registerEvents(new DeathListener(this), this);
      this.soullessBladeListener = new SoullessBladeListener(this);
      this.getServer().getPluginManager().registerEvents(this.soullessBladeListener, this);
      this.getCommand("ability").setExecutor(new AbilityCommand(this));
      ReviveCommand reviveCommand = new ReviveCommand(this);
      this.getCommand("revive").setExecutor(reviveCommand);
      this.getCommand("revive").setTabCompleter(reviveCommand);
      SoulCommand soulCommand = new SoulCommand(this);
      this.getCommand("soul").setExecutor(soulCommand);
      this.getCommand("soul").setTabCompleter(soulCommand);
      this.getCommand("soulbladetest").setExecutor(new SoulBladeTestCommand(this));
      SelfSoulCommand selfSoulCommand = new SelfSoulCommand(this);
      this.getCommand("selfsoul").setExecutor(selfSoulCommand);
      this.getCommand("selfsoul").setTabCompleter(selfSoulCommand);
      DropSoulCommand dropSoulCommand = new DropSoulCommand(this);
      this.getCommand("withdraw").setExecutor(dropSoulCommand);
      this.getServer().getPluginManager().registerEvents(dropSoulCommand, this);
      this.getCommand("soulsword").setExecutor((sender, command, label, args) -> {
         if (sender instanceof Player player) {
            if (!player.isOp()) {
               return true;
            } else {
               player.getInventory().addItem(new ItemStack[]{this.soullessBladeListener.createSoullessBlade()});
               return true;
            }
         } else {
            return true;
         }
      });
      this.getServer().getPluginManager().registerEvents(new FireAspectRemovalListener(this), this);
      this.targetModeManager = new TargetModeManager();
      this.gracePeriodManager = new GracePeriodManager(this);
      this.getServer().getPluginManager().registerEvents(this.gracePeriodManager, this);
      TargetCommand targetCommand = new TargetCommand(this);
      this.getCommand("target").setExecutor(targetCommand);
      this.getCommand("target").setTabCompleter(targetCommand);
      GraceCommand graceCommand = new GraceCommand(this);
      this.getCommand("grace").setExecutor(graceCommand);
      this.getCommand("grace").setTabCompleter(graceCommand);
      this.getLogger().info("ShadeSMP has been enabled!");
   }

   public void onDisable() {
      if (this.soulTickTask != null) {
         this.soulTickTask.cancel();
      }

      this.getLogger().info("ShadeSMP has been disabled!");
   }

   public static ShadeSMP getInstance() {
      return instance;
   }

   public SoullessBladeListener getSoullessBladeListener() {
      return this.soullessBladeListener;
   }

   public SoulManager getSoulManager() {
      return this.soulManager;
   }

   public SoulActionBarManager getSoulActionBarManager() {
      return this.soulActionBarManager;
   }

   public VenomSoulListener getVenomSoulListener() {
      return this.venomSoulListener;
   }

   public QuickeningSoulListener getQuickeningSoulListener() {
      return this.quickeningSoulListener;
   }

   public ColdSoulListener getColdSoulListener() {
      return this.coldSoulListener;
   }

   public DarkSoulListener getDarkSoulListener() {
      return this.darkSoulListener;
   }

   public SharpSoulListener getSharpSoulListener() {
      return this.sharpSoulListener;
   }

   public FlamingSoulListener getFlamingSoulListener() {
      return this.flamingSoulListener;
   }

   public SoullessSoulListener getSoullessSoulListener() {
      return this.soullessSoulListener;
   }

   public GracePeriodManager getGracePeriodManager() {
      return this.gracePeriodManager;
   }

   public TargetModeManager getTargetModeManager() {
      return this.targetModeManager;
   }
}
