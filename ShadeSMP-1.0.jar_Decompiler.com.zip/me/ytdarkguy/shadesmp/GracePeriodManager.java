package me.ytdarkguy.shadesmp;

import java.time.Duration;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.bossbar.BossBar.Color;
import net.kyori.adventure.bossbar.BossBar.Overlay;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.title.Title.Times;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class GracePeriodManager implements Listener {
   private final ShadeSMP plugin;
   private boolean active = false;
   private BossBar bossBar = null;
   private BukkitTask tickTask = null;
   private long totalTicks;
   private long remainingTicks;

   public GracePeriodManager(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public boolean isActive() {
      return this.active;
   }

   public void start(long durationSeconds) {
      if (this.active) {
         this.stop(false);
      }

      this.active = true;
      this.totalTicks = durationSeconds * 20L;
      this.remainingTicks = this.totalTicks;
      Component barName = this.buildBarName();
      this.bossBar = BossBar.bossBar(barName, 1.0F, Color.YELLOW, Overlay.NOTCHED_20);

      for(Player p : Bukkit.getOnlinePlayers()) {
         p.showBossBar(this.bossBar);
      }

      this.tickTask = (new BukkitRunnable() {
         public void run() {
            GracePeriodManager var10000 = GracePeriodManager.this;
            var10000.remainingTicks -= 20L;
            if (GracePeriodManager.this.remainingTicks <= 0L) {
               GracePeriodManager.this.stop(true);
            } else {
               float progress = (float)GracePeriodManager.this.remainingTicks / (float)GracePeriodManager.this.totalTicks;
               GracePeriodManager.this.bossBar.progress(Math.max(0.0F, Math.min(1.0F, progress)));
            }
         }
      }).runTaskTimer(this.plugin, 20L, 20L);
   }

   public void stop(boolean sendTitle) {
      if (this.active) {
         this.active = false;
         if (this.tickTask != null) {
            this.tickTask.cancel();
            this.tickTask = null;
         }

         if (this.bossBar != null) {
            for(Player p : Bukkit.getOnlinePlayers()) {
               p.hideBossBar(this.bossBar);
            }

            this.bossBar = null;
         }

         if (sendTitle) {
            Component mainTitle = Component.text("Good luck!", TextColor.color(16733525)).decoration(TextDecoration.ITALIC, false);
            Component subtitle = Component.empty();
            Title title = Title.title(mainTitle, subtitle, Times.times(Duration.ofMillis(500L), Duration.ofMillis(3000L), Duration.ofMillis(1000L)));

            for(Player p : Bukkit.getOnlinePlayers()) {
               p.showTitle(title);
               p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
            }
         }

      }
   }

   public void showToPlayer(Player player) {
      if (this.active && this.bossBar != null) {
         player.showBossBar(this.bossBar);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityDamage(EntityDamageByEntityEvent event) {
      if (this.active) {
         if (event.getEntity() instanceof Player) {
            Entity damager = event.getDamager();
            if (!(damager instanceof Player)) {
               if (!(damager instanceof Projectile)) {
                  return;
               }

               Projectile proj = (Projectile)damager;
               if (!(proj.getShooter() instanceof Player)) {
                  return;
               }
            }

            event.setCancelled(true);
         }
      }
   }

   private Component buildBarName() {
      int[] colors = new int[]{16503094, 16502842, 16502590, 16502081, 16501829, -1, 16501577, 16501829, 16502081, 16502590, 16502842, 16503094};
      String chars = "ɢʀᴀᴄᴇ ᴘᴇʀɪᴏᴅ";
      Component result = Component.empty();

      for(int i = 0; i < chars.length(); ++i) {
         String ch = String.valueOf(chars.charAt(i));
         if (colors[i] == -1) {
            result = result.append(Component.text(" "));
         } else {
            result = result.append(((TextComponent)((TextComponent)Component.text(ch, TextColor.color(colors[i])).decoration(TextDecoration.BOLD, true)).decoration(TextDecoration.UNDERLINED, true)).decoration(TextDecoration.ITALIC, false));
         }
      }

      return result;
   }
}
