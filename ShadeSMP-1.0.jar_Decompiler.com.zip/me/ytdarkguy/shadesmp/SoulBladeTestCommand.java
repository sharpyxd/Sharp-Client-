package me.ytdarkguy.shadesmp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class SoulBladeTestCommand implements CommandExecutor {
   private final ShadeSMP plugin;
   private static final double RADIUS = (double)10.0F;
   private static final int DEBUFF_DURATION_TICKS = 100;

   public SoulBladeTestCommand(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!player.isOp()) {
            return true;
         } else {
            this.fireSoulSplash(player);
            return true;
         }
      } else {
         return true;
      }
   }

   private void fireSoulSplash(Player player) {
      Location loc = player.getLocation();
      World world = player.getWorld();
      long now = System.currentTimeMillis();
      world.spawnParticle(Particle.SOUL, loc, 80, (double)5.0F, (double)1.0F, (double)5.0F, 0.05);
      world.playSound(loc, Sound.BLOCK_SOUL_SAND_PLACE, 2.0F, 0.6F);
      world.playSound(loc, Sound.ENTITY_WITHER_SHOOT, 1.0F, 1.8F);
      final SoullessBladeListener bladeListener = this.plugin.getSoullessBladeListener();

      for(Entity entity : world.getNearbyEntities(loc, (double)10.0F, (double)10.0F, (double)10.0F)) {
         if (entity instanceof LivingEntity target) {
            bladeListener.markSoulSplashed(entity.getUniqueId(), now + 5000L);
            target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 0, false, true, true));
            entity.setGlowing(true);
            world.spawnParticle(Particle.SOUL_FIRE_FLAME, entity.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, 0.3, (double)0.5F, 0.3, 0.05);
         }
      }

      (new BukkitRunnable() {
         public void run() {
            bladeListener.cleanupExpiredSoulSplash();

            for(World w : Bukkit.getWorlds()) {
               for(Entity e : w.getEntities()) {
                  if (!bladeListener.isSoulSplashed(e.getUniqueId())) {
                     e.setGlowing(false);
                  }
               }
            }

         }
      }).runTaskLater(this.plugin, 102L);
   }
}
