package me.ytdarkguy.shadesmp;

import java.util.List;
import java.util.Random;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

public enum PlayerSoul {
   COLD_SOUL("Cold Soul", 7650303),
   QUICKENING("Quickening Soul", 16777045),
   DARK_SOUL("Dark Soul", 5444514),
   VENOM_SOUL("Venom Soul", 5614165),
   SHARP_SOUL("Sharp Soul", 8286917),
   FLAMING_SOUL("Flaming Soul", 14628663),
   SOULLESS("Soulless", 2829099, false);

   private final String displayName;
   private final TextColor color;
   private final boolean spawnable;
   private static final List<PlayerSoul> VALUES = List.of(values());
   private static final List<PlayerSoul> SPAWNABLE = VALUES.stream().filter(PlayerSoul::isSpawnable).toList();
   private static final Random RANDOM = new Random();

   private PlayerSoul(String displayName, int rgb) {
      this(displayName, rgb, true);
   }

   private PlayerSoul(String displayName, int rgb, boolean spawnable) {
      this.displayName = displayName;
      this.color = TextColor.color(rgb);
      this.spawnable = spawnable;
   }

   public boolean isSpawnable() {
      return this.spawnable;
   }

   public TextColor getColor() {
      return this.color;
   }

   public Component actionBarComponent() {
      return Component.text(this.displayName, this.color);
   }

   public static PlayerSoul random() {
      return (PlayerSoul)SPAWNABLE.get(RANDOM.nextInt(SPAWNABLE.size()));
   }

   public String key() {
      return this.name();
   }

   public static PlayerSoul fromKey(String key) {
      try {
         return valueOf(key);
      } catch (IllegalArgumentException var2) {
         return null;
      }
   }

   // $FF: synthetic method
   private static PlayerSoul[] $values() {
      return new PlayerSoul[]{COLD_SOUL, QUICKENING, DARK_SOUL, VENOM_SOUL, SHARP_SOUL, FLAMING_SOUL, SOULLESS};
   }
}
