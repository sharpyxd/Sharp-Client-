package me.ytdarkguy.shadesmp;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.entity.Creature;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Ghast;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Phantom;
import org.bukkit.entity.Piglin;
import org.bukkit.entity.PiglinBrute;
import org.bukkit.entity.Player;
import org.bukkit.entity.Slime;

public class TargetModeManager {
   private final Map<UUID, TargetMode> modes = new HashMap();

   public TargetMode getMode(Player player) {
      return (TargetMode)this.modes.getOrDefault(player.getUniqueId(), TargetMode.PLAYERS);
   }

   public void setMode(Player player, TargetMode mode) {
      this.modes.put(player.getUniqueId(), mode);
   }

   public void toggle(Player player) {
      this.setMode(player, this.getMode(player) == TargetMode.PLAYERS ? TargetMode.MOBS : TargetMode.PLAYERS);
   }

   public static boolean isHostileMob(Entity entity) {
      if (entity instanceof Player) {
         return false;
      } else if (entity instanceof Monster) {
         return true;
      } else if (entity instanceof Slime) {
         return true;
      } else if (entity instanceof Ghast) {
         return true;
      } else if (entity instanceof Phantom) {
         return true;
      } else if (entity instanceof PiglinBrute) {
         return true;
      } else if (entity instanceof IronGolem) {
         IronGolem golem = (IronGolem)entity;
         return golem.getTarget() != null;
      } else if (entity instanceof Piglin) {
         return true;
      } else if (entity instanceof Creature) {
         Creature creature = (Creature)entity;
         Entity target = creature.getTarget();
         return target instanceof Player;
      } else {
         return false;
      }
   }
}
