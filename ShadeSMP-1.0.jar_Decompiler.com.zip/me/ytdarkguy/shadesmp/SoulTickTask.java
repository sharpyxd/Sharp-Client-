package me.ytdarkguy.shadesmp;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class SoulTickTask {
   private final ShadeSMP plugin;
   private BukkitTask task;

   public SoulTickTask(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public void start() {
      this.task = (new BukkitRunnable() {
         public void run() {
            for(Player player : Bukkit.getOnlinePlayers()) {
               PlayerSoul soul = SoulTickTask.this.plugin.getSoulManager().getSoul(player);
               if (soul != null) {
                  if (soul == PlayerSoul.QUICKENING) {
                     SoulTickTask.this.plugin.getQuickeningSoulListener().tickPlayer(player);
                  }

                  if (soul == PlayerSoul.FLAMING_SOUL) {
                     SoulTickTask.this.plugin.getFlamingSoulListener().tickPlayer(player);
                  }

                  SoulTickTask.this.spawnSoulParticle(player, soul);
               }
            }

         }
      }).runTaskTimer(this.plugin, 20L, 19L);
   }

   private void spawnSoulParticle(Player player, PlayerSoul soul) {
      int rgb = this.soulRgb(soul);
      float r = (float)(rgb >> 16 & 255) / 255.0F;
      float g = (float)(rgb >> 8 & 255) / 255.0F;
      float b = (float)(rgb & 255) / 255.0F;
      Color dustColor = Color.fromRGB(rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255);
      Particle.DustOptions dust = new Particle.DustOptions(dustColor, 1.2F);
      Location loc = player.getLocation().add((double)0.0F, 1.2, (double)0.0F);
      player.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.3, 0.4, 0.3, (double)0.0F, dust);
   }

   private int soulRgb(PlayerSoul soul) {
      int var10000;
      switch (soul) {
         case COLD_SOUL -> var10000 = 7650303;
         case QUICKENING -> var10000 = 16777045;
         case DARK_SOUL -> var10000 = 5444514;
         case VENOM_SOUL -> var10000 = 5614165;
         case SHARP_SOUL -> var10000 = 8286917;
         case FLAMING_SOUL -> var10000 = 14628663;
         case SOULLESS -> var10000 = 2829099;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public void cancel() {
      if (this.task != null) {
         this.task.cancel();
      }

   }
}
