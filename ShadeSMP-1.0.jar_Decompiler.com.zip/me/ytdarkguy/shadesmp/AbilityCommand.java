package me.ytdarkguy.shadesmp;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AbilityCommand implements CommandExecutor {
   private final ShadeSMP plugin;

   public AbilityCommand(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         PlayerSoul soul = this.plugin.getSoulManager().getSoul(player);
         if (soul == null) {
            return true;
         } else {
            switch (soul) {
               case VENOM_SOUL -> this.plugin.getVenomSoulListener().triggerAbility(player);
               case QUICKENING -> this.plugin.getQuickeningSoulListener().triggerAbility(player);
               case COLD_SOUL -> this.plugin.getColdSoulListener().triggerAbility(player);
               case DARK_SOUL -> this.plugin.getDarkSoulListener().triggerAbility(player);
               case SHARP_SOUL -> this.plugin.getSharpSoulListener().triggerAbility(player);
               case FLAMING_SOUL -> this.plugin.getFlamingSoulListener().triggerAbility(player);
               case SOULLESS -> this.plugin.getSoullessSoulListener().triggerAbility(player);
            }

            return true;
         }
      } else {
         return true;
      }
   }
}
