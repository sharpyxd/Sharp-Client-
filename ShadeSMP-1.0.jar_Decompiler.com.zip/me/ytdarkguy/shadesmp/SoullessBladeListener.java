package me.ytdarkguy.shadesmp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

public class SoullessBladeListener implements Listener {
   private static final long ABILITY_COOLDOWN_MS = 90000L;
   private static final long ABILITY_WINDOW_MS = 10000L;
   private static final long CURSE_DURATION_MS = 30000L;
   private static final int CURSE_DURATION_TICKS = 600;
   private final ShadeSMP plugin;
   private final NamespacedKey bladeKey;
   private final Map<UUID, Long> armedAt = new HashMap();
   private final Map<UUID, Long> cooldowns = new HashMap();
   private final Map<UUID, Long> cursedPlayers = new HashMap();
   private final Set<UUID> bladeHolders = new HashSet();
   private final Map<UUID, Long> soulSplashedEntities = new HashMap();

   public SoullessBladeListener(ShadeSMP plugin) {
      this.plugin = plugin;
      this.bladeKey = new NamespacedKey(plugin, "soulless_blade");
   }

   public ItemStack createSoullessBlade() {
      ItemStack sword = new ItemStack(Material.NETHERITE_SWORD);
      ItemMeta meta = sword.getItemMeta();
      String gradientName = "§#66FBE1ꜱ§#70FBE0ᴏ§#79FBDFᴜ§#83FBDEʟ§#8CFBDDʟ§#96FBDCᴇ§#9FFBDBꜱ§#96FBDCꜱ §#8CFBDDʙ§#83FBDEʟ§#79FBDFᴀ§#70FBE0ᴅ§#66FBE1ᴇ";
      meta.displayName(LegacyComponentSerializer.legacySection().deserialize(gradientName).decoration(TextDecoration.ITALIC, false));
      List<Component> lore = new ArrayList();
      lore.add(Component.text("the curse of the loneliness the blade brings your soul to", TextColor.color(8947848)).decoration(TextDecoration.ITALIC, false));
      lore.add(Component.empty());
      lore.add(((TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)Component.text("E", TextColor.color(6217211)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true)).append(((TextComponent)Component.text("M", TextColor.color(6676219)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true))).append(((TextComponent)Component.text("P", TextColor.color(7135483)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true))).append(((TextComponent)Component.text("T", TextColor.color(7528955)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true))).append(((TextComponent)Component.text("I", TextColor.color(7987963)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true))).append(((TextComponent)Component.text("N", TextColor.color(7528955)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true))).append(((TextComponent)Component.text("E", TextColor.color(7135483)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true))).append(((TextComponent)Component.text("S", TextColor.color(6676219)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true))).append(((TextComponent)Component.text("S", TextColor.color(6217211)).decoration(TextDecoration.ITALIC, false)).decoration(TextDecoration.UNDERLINED, true))).append(Component.text(" ʀɪɡʜᴛ-ᴄʟɪᴄᴋ", TextColor.color(8947848)).decoration(TextDecoration.ITALIC, false)));
      lore.add(Component.text("Bring the darkness of the curse to others in your next hit", TextColor.color(10066329)).decoration(TextDecoration.ITALIC, false));
      meta.lore(lore);
      meta.addEnchant(Enchantment.SHARPNESS, 4, true);
      meta.addEnchant(Enchantment.SWEEPING_EDGE, 3, true);
      meta.setUnbreakable(true);
      meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_UNBREAKABLE});
      meta.getPersistentDataContainer().set(this.bladeKey, PersistentDataType.BYTE, (byte)1);
      sword.setItemMeta(meta);
      return sword;
   }

   public boolean isSoullessBlade(ItemStack item) {
      return item != null && item.hasItemMeta() ? item.getItemMeta().getPersistentDataContainer().has(this.bladeKey, PersistentDataType.BYTE) : false;
   }

   public void tickInventoryCheck() {
      for(Player player : Bukkit.getOnlinePlayers()) {
         boolean hasBlade = this.hasSoullessBlade(player);
         UUID uid = player.getUniqueId();
         if (hasBlade) {
            if (!this.bladeHolders.contains(uid)) {
               this.bladeHolders.add(uid);
               this.plugin.getSoulManager().setSoulSilent(player, PlayerSoul.SOULLESS);
            }
         } else if (this.bladeHolders.remove(uid)) {
         }
      }

   }

   private boolean hasSoullessBlade(Player player) {
      for(ItemStack item : player.getInventory().getContents()) {
         if (this.isSoullessBlade(item)) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      HumanEntity var3 = event.getWhoClicked();
      if (var3 instanceof Player player) {
         (new BukkitRunnable() {
            public void run() {
               SoullessBladeListener.this.tickInventoryCheck();
            }
         }).runTaskLater(this.plugin, 1L);
      }
   }

   @EventHandler
   public void onDrop(PlayerDropItemEvent event) {
      (new BukkitRunnable() {
         public void run() {
            SoullessBladeListener.this.tickInventoryCheck();
         }
      }).runTaskLater(this.plugin, 1L);
   }

   @EventHandler
   public void onCrouchSwapHand(PlayerSwapHandItemsEvent event) {
      if (event.getPlayer().isSneaking()) {
         ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
         if (this.isSoullessBlade(item)) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            final UUID uid = player.getUniqueId();
            final long now = System.currentTimeMillis();
            Long cdExpiry = (Long)this.cooldowns.get(uid);
            if (cdExpiry == null || cdExpiry <= now) {
               if (this.armedAt.containsKey(uid)) {
                  this.armedAt.remove(uid);
               } else {
                  this.armedAt.put(uid, now);
                  player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.6F, 1.8F);
                  player.getWorld().spawnParticle(Particle.SOUL, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, 0.6, (double)0.5F, 0.02);
                  (new BukkitRunnable() {
                     public void run() {
                        if (SoullessBladeListener.this.armedAt.containsKey(uid) && ((Long)SoullessBladeListener.this.armedAt.get(uid)).equals(now)) {
                           SoullessBladeListener.this.armedAt.remove(uid);
                        }

                     }
                  }).runTaskLater(this.plugin, 200L);
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onHit(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         Entity var4 = event.getEntity();
         if (var4 instanceof Player target) {
            UUID var9 = attacker.getUniqueId();
            if (this.armedAt.containsKey(var9)) {
               ItemStack held = attacker.getInventory().getItemInMainHand();
               if (this.isSoullessBlade(held)) {
                  long now = System.currentTimeMillis();
                  this.armedAt.remove(var9);
                  this.cooldowns.put(var9, now + 90000L);
                  this.applyCurse(attacker, target, now);
               }
            }
         }
      }
   }

   private void applyCurse(Player caster, final Player target, long now) {
      final UUID targetUid = target.getUniqueId();
      this.cursedPlayers.put(targetUid, now + 30000L);
      caster.playSound(caster.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.5F, 1.6F);
      target.playSound(target.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.8F, 0.8F);
      final long curseExpiry = now + 30000L;
      (new BukkitRunnable() {
         public void run() {
            if (target.isOnline() && System.currentTimeMillis() <= curseExpiry) {
               Location tLoc = target.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
               World world = target.getWorld();
               world.spawnParticle(Particle.SOUL_FIRE_FLAME, tLoc, 6, 0.4, 0.6, 0.4, 0.01);
               world.spawnParticle(Particle.SOUL, tLoc, 4, 0.3, (double)0.5F, 0.3, 0.01);
               Location feet = target.getLocation();
               world.spawnParticle(Particle.SMOKE, feet, 3, 0.1, 0.05, 0.1, 0.01);
            } else {
               this.cancel();
            }
         }
      }).runTaskTimer(this.plugin, 0L, 4L);
      (new BukkitRunnable() {
         public void run() {
            SoullessBladeListener.this.cursedPlayers.remove(targetUid);
            if (target.isOnline()) {
               target.playSound(target.getLocation(), Sound.BLOCK_SOUL_SAND_PLACE, 0.8F, 1.2F);
            }

         }
      }).runTaskLater(this.plugin, 600L);
   }

   public int adjustedChance(Player player, int basePct) {
      return this.isCursed(player) ? basePct / 2 : basePct;
   }

   public long adjustedCooldownExpiry(Player player, long storedExpiry) {
      if (!this.isCursed(player)) {
         return storedExpiry;
      } else {
         long now = System.currentTimeMillis();
         long curseExpiry = (Long)this.cursedPlayers.get(player.getUniqueId());
         long remainCurse = Math.max(0L, curseExpiry - now);
         long extra = remainCurse / 2L;
         return storedExpiry + extra;
      }
   }

   public boolean isCursed(Player player) {
      Long expiry = (Long)this.cursedPlayers.get(player.getUniqueId());
      if (expiry == null) {
         return false;
      } else if (expiry <= System.currentTimeMillis()) {
         this.cursedPlayers.remove(player.getUniqueId());
         return false;
      } else {
         return true;
      }
   }

   public boolean isArmed(UUID uid) {
      return this.armedAt.containsKey(uid);
   }

   public Map<UUID, Long> getCooldowns() {
      return this.cooldowns;
   }

   public void markSoulSplashed(UUID uid, long expiryMs) {
      this.soulSplashedEntities.put(uid, expiryMs);
   }

   public boolean isSoulSplashed(UUID uid) {
      Long expiry = (Long)this.soulSplashedEntities.get(uid);
      if (expiry == null) {
         return false;
      } else if (System.currentTimeMillis() >= expiry) {
         this.soulSplashedEntities.remove(uid);
         return false;
      } else {
         return true;
      }
   }

   public void cleanupExpiredSoulSplash() {
      long now = System.currentTimeMillis();
      this.soulSplashedEntities.entrySet().removeIf((e) -> now >= (Long)e.getValue());
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      UUID uid = event.getPlayer().getUniqueId();
      this.armedAt.remove(uid);
      this.cooldowns.remove(uid);
      this.bladeHolders.remove(uid);
   }
}
