package me.ytdarkguy.shadesmp;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class SoulManager implements Listener {
   private final ShadeSMP plugin;
   private final File soulsFile;
   private YamlConfiguration soulsConfig;
   private final Map<UUID, PlayerSoul> soulMap = new HashMap();

   public SoulManager(ShadeSMP plugin) {
      this.plugin = plugin;
      this.soulsFile = new File(plugin.getDataFolder(), "souls.yml");
      this.load();
      this.startActionBarTask();
   }

   private void load() {
      if (!this.plugin.getDataFolder().exists()) {
         this.plugin.getDataFolder().mkdirs();
      }

      if (!this.soulsFile.exists()) {
         try {
            this.soulsFile.createNewFile();
         } catch (IOException e) {
            this.plugin.getLogger().severe("Could not create souls.yml: " + e.getMessage());
         }
      }

      this.soulsConfig = YamlConfiguration.loadConfiguration(this.soulsFile);
      ConfigurationSection section = this.soulsConfig.getConfigurationSection("souls");
      if (section != null) {
         for(String key : section.getKeys(false)) {
            try {
               UUID uuid = UUID.fromString(key);
               PlayerSoul soul = PlayerSoul.fromKey(section.getString(key, ""));
               if (soul != null) {
                  this.soulMap.put(uuid, soul);
               }
            } catch (IllegalArgumentException var6) {
            }
         }

         this.plugin.getLogger().info("Loaded " + this.soulMap.size() + " player soul(s) from souls.yml.");
      }
   }

   private void save() {
      for(Map.Entry<UUID, PlayerSoul> entry : this.soulMap.entrySet()) {
         this.soulsConfig.set("souls." + ((UUID)entry.getKey()).toString(), ((PlayerSoul)entry.getValue()).key());
      }

      try {
         this.soulsConfig.save(this.soulsFile);
      } catch (IOException e) {
         this.plugin.getLogger().severe("Could not save souls.yml: " + e.getMessage());
      }

   }

   @EventHandler
   public void onFirstJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      UUID uuid = player.getUniqueId();
      if (!this.soulMap.containsKey(uuid)) {
         PlayerSoul soul = PlayerSoul.random();
         this.soulMap.put(uuid, soul);
         this.save();
         this.plugin.getGracePeriodManager().showToPlayer(player);
      }
   }

   private void startActionBarTask() {
      (new BukkitRunnable() {
         public void run() {
            SoulActionBarManager actionBar = SoulManager.this.plugin.getSoulActionBarManager();

            for(Player player : Bukkit.getOnlinePlayers()) {
               PlayerSoul soul = (PlayerSoul)SoulManager.this.soulMap.get(player.getUniqueId());
               if (soul != null && actionBar != null) {
                  actionBar.update(player);
               }
            }

         }
      }).runTaskTimer(this.plugin, 0L, 40L);
   }

   public PlayerSoul getSoul(UUID uuid) {
      return (PlayerSoul)this.soulMap.get(uuid);
   }

   public PlayerSoul getSoul(Player player) {
      return this.getSoul(player.getUniqueId());
   }

   public void setSoul(Player player, PlayerSoul soul) {
      this.soulMap.put(player.getUniqueId(), soul);
      this.save();
   }

   public void setSoulSilent(Player player, PlayerSoul soul) {
      this.soulMap.put(player.getUniqueId(), soul);
      this.save();
   }
}
