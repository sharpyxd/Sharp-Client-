package me.ytdarkguy.shadesmp;

import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class TargetCommand implements CommandExecutor, TabCompleter {
   private final ShadeSMP plugin;

   public TargetCommand(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         TargetModeManager mgr = this.plugin.getTargetModeManager();
         if (args.length == 0) {
            mgr.toggle(player);
         } else {
            switch (args[0].toLowerCase()) {
               case "players":
                  mgr.setMode(player, TargetMode.PLAYERS);
                  break;
               case "mobs":
                  mgr.setMode(player, TargetMode.MOBS);
                  break;
               default:
                  player.sendMessage(Component.text("Usage: /target [players|mobs]", TextColor.color(16733525)));
                  return true;
            }
         }

         TargetMode current = mgr.getMode(player);
         String modeLabel = current == TargetMode.PLAYERS ? "Players" : "Hostile Mobs";
         int modeColor = current == TargetMode.PLAYERS ? 5636095 : 16733525;
         player.sendMessage(Component.text("Soul target mode: ", TextColor.color(11184810)).append(Component.text(modeLabel, TextColor.color(modeColor))));
         return true;
      } else {
         sender.sendMessage("Only players can use this command.");
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return args.length == 1 ? List.of("players", "mobs") : List.of();
   }
}
