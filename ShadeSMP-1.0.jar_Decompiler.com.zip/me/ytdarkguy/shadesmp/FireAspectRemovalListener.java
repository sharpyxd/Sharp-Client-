package me.ytdarkguy.shadesmp;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

public class FireAspectRemovalListener implements Listener {
   private final ShadeSMP plugin;

   public FireAspectRemovalListener(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      this.stripInventory(event.getPlayer());
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEnchant(final EnchantItemEvent event) {
      boolean containsFire = event.getEnchantsToAdd().keySet().stream().anyMatch((e) -> e.equals(Enchantment.FIRE_ASPECT) || e.equals(Enchantment.FLAME));
      if (containsFire) {
         event.setCancelled(true);
      } else {
         (new BukkitRunnable() {
            public void run() {
               FireAspectRemovalListener.this.stripInventory(event.getEnchanter());
            }
         }).runTaskLater(this.plugin, 1L);
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPrepareAnvil(PrepareAnvilEvent event) {
      ItemStack result = event.getResult();
      if (result != null) {
         ItemStack stripped = this.strip(result);
         event.setResult(stripped);
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onInventoryClick(InventoryClickEvent event) {
      HumanEntity var3 = event.getWhoClicked();
      if (var3 instanceof final Player player) {
         (new BukkitRunnable() {
            public void run() {
               if (player.isOnline()) {
                  FireAspectRemovalListener.this.stripInventory(player);
               }

            }
         }).runTaskLater(this.plugin, 1L);
      }
   }

   @EventHandler
   public void onHeldItemChange(final PlayerItemHeldEvent event) {
      (new BukkitRunnable() {
         public void run() {
            if (event.getPlayer().isOnline()) {
               FireAspectRemovalListener.this.stripInventory(event.getPlayer());
            }

         }
      }).runTaskLater(this.plugin, 1L);
   }

   public void stripInventory(Player player) {
      ItemStack[] contents = player.getInventory().getContents();
      boolean changed = false;

      for(int i = 0; i < contents.length; ++i) {
         ItemStack original = contents[i];
         if (original != null && original.getType() != Material.AIR) {
            ItemStack stripped = this.strip(original);
            if (stripped != original) {
               contents[i] = stripped;
               changed = true;
            }
         }
      }

      if (changed) {
         player.getInventory().setContents(contents);
      }

   }

   public ItemStack strip(ItemStack item) {
      if (item != null && item.hasItemMeta()) {
         boolean hasFireAspect = item.containsEnchantment(Enchantment.FIRE_ASPECT);
         boolean hasFlame = item.containsEnchantment(Enchantment.FLAME);
         boolean hasStoredFireAspect = false;
         boolean hasStoredFlame = false;
         ItemMeta var7 = item.getItemMeta();
         if (var7 instanceof EnchantmentStorageMeta) {
            EnchantmentStorageMeta esm = (EnchantmentStorageMeta)var7;
            hasStoredFireAspect = esm.hasStoredEnchant(Enchantment.FIRE_ASPECT);
            hasStoredFlame = esm.hasStoredEnchant(Enchantment.FLAME);
         }

         if (!hasFireAspect && !hasFlame && !hasStoredFireAspect && !hasStoredFlame) {
            return item;
         } else {
            ItemStack result = item.clone();
            result.removeEnchantment(Enchantment.FIRE_ASPECT);
            result.removeEnchantment(Enchantment.FLAME);
            ItemMeta var8 = result.getItemMeta();
            if (var8 instanceof EnchantmentStorageMeta) {
               EnchantmentStorageMeta esm = (EnchantmentStorageMeta)var8;
               esm.removeStoredEnchant(Enchantment.FIRE_ASPECT);
               esm.removeStoredEnchant(Enchantment.FLAME);
               result.setItemMeta(esm);
               if (esm.getStoredEnchants().isEmpty()) {
                  ItemStack book = new ItemStack(Material.BOOK, result.getAmount());
                  ItemMeta bookMeta = book.getItemMeta();
                  if (esm.hasDisplayName()) {
                     bookMeta.displayName(esm.displayName());
                  }

                  if (esm.hasLore()) {
                     bookMeta.lore(esm.lore());
                  }

                  book.setItemMeta(bookMeta);
                  return book;
               }
            }

            return result;
         }
      } else {
         return item;
      }
   }
}
