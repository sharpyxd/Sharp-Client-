package me.ytdarkguy.shadesmp;

public enum TargetMode {
   PLAYERS,
   MOBS;

   // $FF: synthetic method
   private static TargetMode[] $values() {
      return new TargetMode[]{PLAYERS, MOBS};
   }
}
