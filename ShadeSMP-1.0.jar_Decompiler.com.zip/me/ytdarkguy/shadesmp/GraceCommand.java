package me.ytdarkguy.shadesmp;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public class GraceCommand implements CommandExecutor, TabCompleter {
   private final ShadeSMP plugin;

   public GraceCommand(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.isOp()) {
         sender.sendMessage("§cYou don't have permission to use this command.");
         return true;
      } else if (args.length < 2) {
         sender.sendMessage("§cUsage: /grace <worldBorderSize> <blocksPerMinute>");
         return true;
      } else {
         double borderSize;
         try {
            borderSize = Double.parseDouble(args[0]);
         } catch (NumberFormatException var18) {
            sender.sendMessage("§cInvalid world border size: " + args[0]);
            return true;
         }

         double blocksPerMinute;
         try {
            blocksPerMinute = Double.parseDouble(args[1]);
         } catch (NumberFormatException var17) {
            sender.sendMessage("§cInvalid speed (blocks/minute): " + args[1]);
            return true;
         }

         if (borderSize <= (double)0.0F) {
            sender.sendMessage("§cWorld border size must be positive.");
            return true;
         } else if (blocksPerMinute <= (double)0.0F) {
            sender.sendMessage("§cBorder speed must be positive.");
            return true;
         } else {
            long durationSeconds = Math.round(borderSize / blocksPerMinute * (double)60.0F);
            WorldBorder border = ((World)Bukkit.getWorlds().get(0)).getWorldBorder();
            border.setSize(borderSize);
            border.setSize((double)0.0F, durationSeconds);
            this.plugin.getGracePeriodManager().start(durationSeconds);
            long totalMinutes = durationSeconds / 60L;
            long remSeconds = durationSeconds % 60L;
            String timeStr = totalMinutes > 0L ? totalMinutes + "m" + (remSeconds > 0L ? " " + remSeconds + "s" : "") : remSeconds + "s";
            Bukkit.broadcastMessage("§eGrace period started! World border: §f" + (int)borderSize + " blocks§e shrinking at §f" + blocksPerMinute + " blocks/min§e. Closes in: §f" + timeStr + "§e.");
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length == 1) {
         return List.of("1000", "500", "250");
      } else {
         return args.length == 2 ? List.of("10", "5", "2") : List.of();
      }
   }
}
