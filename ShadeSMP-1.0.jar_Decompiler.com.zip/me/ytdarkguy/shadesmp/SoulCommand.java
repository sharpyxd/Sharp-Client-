package me.ytdarkguy.shadesmp;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class SoulCommand implements CommandExecutor, TabCompleter {
   private final ShadeSMP plugin;

   public SoulCommand(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!player.isOp()) {
            return true;
         } else if (args.length >= 1 && args.length <= 2) {
            PlayerSoul soul = PlayerSoul.fromKey(args[0].toUpperCase());
            if (soul == null) {
               this.sendSoulList(player);
               return true;
            } else {
               if (args.length == 2) {
                  Player target = Bukkit.getPlayer(args[1]);
                  if (target == null) {
                     return true;
                  }

                  this.plugin.getSoulManager().setSoul(target, soul);
               } else {
                  this.plugin.getSoulManager().setSoul(player, soul);
               }

               return true;
            }
         } else {
            this.sendSoulList(player);
            return true;
         }
      } else {
         return true;
      }
   }

   private void sendSoulList(Player player) {
      StringBuilder sb = new StringBuilder("Available: ");
      PlayerSoul[] values = PlayerSoul.values();

      for(int i = 0; i < values.length; ++i) {
         sb.append(values[i].key());
         if (i < values.length - 1) {
            sb.append(", ");
         }
      }

   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.isOp()) {
         return List.of();
      } else if (args.length == 1) {
         List<String> completions = new ArrayList();
         String input = args[0].toUpperCase();

         for(PlayerSoul soul : PlayerSoul.values()) {
            if (soul.key().startsWith(input)) {
               completions.add(soul.key());
            }
         }

         return completions;
      } else if (args.length == 2) {
         List<String> names = new ArrayList();
         String input = args[1].toLowerCase();

         for(Player p : Bukkit.getOnlinePlayers()) {
            if (p.getName().toLowerCase().startsWith(input)) {
               names.add(p.getName());
            }
         }

         return names;
      } else {
         return List.of();
      }
   }
}
