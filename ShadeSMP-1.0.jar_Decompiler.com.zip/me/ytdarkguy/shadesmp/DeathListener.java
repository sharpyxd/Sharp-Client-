package me.ytdarkguy.shadesmp;

import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class DeathListener implements Listener {
   private final ShadeSMP plugin;
   private final NamespacedKey soulOwnerKey;
   private final NamespacedKey soulTypeKey;
   private static final Material SOUL_MATERIAL;
   private static final String TEAM_PREFIX = "shade_soul_";

   public DeathListener(ShadeSMP plugin) {
      this.plugin = plugin;
      this.soulOwnerKey = new NamespacedKey(plugin, "soul_owner");
      this.soulTypeKey = new NamespacedKey(plugin, "soul_type");
      this.ensureSoulTeams();
   }

   private void ensureSoulTeams() {
      Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();

      for(PlayerSoul soul : PlayerSoul.values()) {
         String teamName = "shade_soul_" + soul.key();
         Team team = board.getTeam(teamName);
         if (team == null) {
            team = board.registerNewTeam(teamName);
         }

         team.color(this.soulNamedColor(soul));
      }

   }

   private NamedTextColor soulNamedColor(PlayerSoul soul) {
      NamedTextColor var10000;
      switch (soul) {
         case COLD_SOUL -> var10000 = NamedTextColor.AQUA;
         case QUICKENING -> var10000 = NamedTextColor.YELLOW;
         case DARK_SOUL -> var10000 = NamedTextColor.DARK_PURPLE;
         case VENOM_SOUL -> var10000 = NamedTextColor.DARK_GREEN;
         case SHARP_SOUL -> var10000 = NamedTextColor.BLUE;
         case FLAMING_SOUL -> var10000 = NamedTextColor.RED;
         case SOULLESS -> var10000 = NamedTextColor.DARK_GRAY;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private void applyGlowColor(Item droppedItem, PlayerSoul soul) {
      Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
      String teamName = "shade_soul_" + soul.key();
      Team team = board.getTeam(teamName);
      if (team == null) {
         this.ensureSoulTeams();
         team = board.getTeam(teamName);
      }

      if (team != null) {
         team.addEntry(droppedItem.getUniqueId().toString());
      }

      droppedItem.setGlowing(true);
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerDeath(PlayerDeathEvent event) {
      Player killed = event.getEntity();
      String killerName = "the void";
      if (killed.getKiller() != null) {
         killerName = killed.getKiller().getName();
      }

      event.getDrops().clear();
      Location deathLocation = killed.getLocation();
      ItemStack soulItem = this.createSoulItem(killed);
      this.plugin.getSoulManager().setSoulSilent(killed, PlayerSoul.SOULLESS);
      deathLocation.getWorld().dropItemNaturally(deathLocation, soulItem);
      Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         if (killed.isOnline()) {
            killed.setGameMode(GameMode.SPECTATOR);
         }

      }, 1L);
   }

   @EventHandler
   public void onItemSpawn(ItemSpawnEvent event) {
      Item droppedItem = event.getEntity();
      ItemStack stack = droppedItem.getItemStack();
      if (stack.getType() == SOUL_MATERIAL) {
         if (stack.hasItemMeta()) {
            PersistentDataContainer pdc = stack.getItemMeta().getPersistentDataContainer();
            if (pdc.has(this.soulOwnerKey, PersistentDataType.STRING)) {
               String soulKey = (String)pdc.get(this.soulTypeKey, PersistentDataType.STRING);
               PlayerSoul soul = soulKey != null ? PlayerSoul.fromKey(soulKey) : null;
               if (soul != null) {
                  this.applyGlowColor(droppedItem, soul);
               } else {
                  droppedItem.setGlowing(true);
               }

            }
         }
      }
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent event) {
      Action action = event.getAction();
      boolean isRightClick = action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK;
      boolean isLeftClick = action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK;
      if (isRightClick || isLeftClick) {
         ItemStack item = event.getItem();
         if (item != null && item.getType() == SOUL_MATERIAL) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
               PersistentDataContainer pdc = meta.getPersistentDataContainer();
               if (pdc.has(this.soulOwnerKey, PersistentDataType.STRING)) {
                  String ownerUUIDStr = (String)pdc.get(this.soulOwnerKey, PersistentDataType.STRING);
                  if (ownerUUIDStr != null) {
                     UUID ownerUUID;
                     try {
                        ownerUUID = UUID.fromString(ownerUUIDStr);
                     } catch (IllegalArgumentException var16) {
                        return;
                     }

                     Player interactor = event.getPlayer();
                     event.setCancelled(true);
                     if (isRightClick) {
                        Player soulOwner = Bukkit.getPlayer(ownerUUID);
                        if (soulOwner == null || !soulOwner.isOnline()) {
                           return;
                        }

                        if (soulOwner.equals(interactor)) {
                           return;
                        }

                        soulOwner.teleport(interactor.getLocation());
                        soulOwner.setGameMode(GameMode.SURVIVAL);
                        this.consumeSoulItem(interactor, item);
                     }

                     if (isLeftClick) {
                        SoulManager soulManager = this.plugin.getSoulManager();
                        PlayerSoul holderSoul = soulManager.getSoul(interactor);
                        if (holderSoul == null) {
                           return;
                        }

                        String previousSoulKey = (String)pdc.get(this.soulTypeKey, PersistentDataType.STRING);
                        meta.getPersistentDataContainer().set(this.soulTypeKey, PersistentDataType.STRING, holderSoul.key());
                        String ownerName = this.resolveOwnerName(ownerUUID);
                        meta.displayName(Component.text(ownerName + "'s ", NamedTextColor.YELLOW).append(holderSoul.actionBarComponent()));
                        if (previousSoulKey != null) {
                           PlayerSoul previousSoul = PlayerSoul.fromKey(previousSoulKey);
                           if (previousSoul != null) {
                              soulManager.setSoul(interactor, previousSoul);
                           }
                        }

                        item.setItemMeta(meta);
                     }

                  }
               }
            }
         }
      }
   }

   private void consumeSoulItem(Player player, ItemStack item) {
      if (item.getAmount() > 1) {
         item.setAmount(item.getAmount() - 1);
      } else {
         player.getInventory().remove(item);
      }

   }

   private String resolveOwnerName(UUID uuid) {
      OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
      return op.getName() != null ? op.getName() : uuid.toString().substring(0, 8);
   }

   private ItemStack createSoulItem(Player player) {
      ItemStack item = new ItemStack(SOUL_MATERIAL);
      ItemMeta meta = item.getItemMeta();
      PlayerSoul soul = this.plugin.getSoulManager().getSoul(player);
      Component itemName;
      if (soul != null) {
         itemName = Component.text(player.getName() + "'s ", NamedTextColor.YELLOW).append(soul.actionBarComponent());
      } else {
         itemName = Component.text(player.getName() + "'s ", NamedTextColor.YELLOW).append(Component.text("Lost Soul", NamedTextColor.AQUA));
      }

      meta.displayName(itemName);
      meta.getPersistentDataContainer().set(this.soulOwnerKey, PersistentDataType.STRING, player.getUniqueId().toString());
      if (soul != null) {
         meta.getPersistentDataContainer().set(this.soulTypeKey, PersistentDataType.STRING, soul.key());
      }

      item.setItemMeta(meta);
      return item;
   }

   static {
      SOUL_MATERIAL = Material.ECHO_SHARD;
   }
}
