package me.ytdarkguy.shadesmp;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;

public class ColdSoulListener implements Listener {
   private static final long COOLDOWN_MS = 45000L;
   private static final int PASSIVE_CHANCE = 10;
   private static final int PASSIVE_SLOW_TICKS = 100;
   private static final int FREEZE_TICKS_MAX = 140;
   private static final int FREEZE_DURATION = 120;
   private static final TextColor COLOR = TextColor.color(7650303);
   private final ShadeSMP plugin;
   private final Map<UUID, Long> cooldowns = new HashMap();
   private final Map<UUID, Location> frozenAt = new HashMap();
   private final Random random = new Random();

   public ColdSoulListener(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onHit(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         if (this.plugin.getSoulManager().getSoul(attacker) == PlayerSoul.COLD_SOUL) {
            Entity var4 = event.getEntity();
            if (var4 instanceof Player) {
               Player target = (Player)var4;
               if (this.random.nextInt(100) < 10) {
                  target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 1, false, true, true));
                  target.setFreezeTicks(200);
               }

            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSwapHandTrigger(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.COLD_SOUL) {
         event.setCancelled(true);
         this.triggerAbility(player);
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onFrozenMove(PlayerMoveEvent event) {
      UUID uid = event.getPlayer().getUniqueId();
      if (this.frozenAt.containsKey(uid)) {
         Location locked = (Location)this.frozenAt.get(uid);
         Location to = event.getTo();
         if (to.getX() != locked.getX() || to.getY() != locked.getY() || to.getZ() != locked.getZ()) {
            Location allowed = locked.clone();
            allowed.setYaw(to.getYaw());
            allowed.setPitch(to.getPitch());
            event.setTo(allowed);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onFrozenEat(FoodLevelChangeEvent event) {
      HumanEntity var3 = event.getEntity();
      if (var3 instanceof Player player) {
         if (this.frozenAt.containsKey(player.getUniqueId())) {
            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onFrozenDamage(EntityDamageByEntityEvent event) {
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onFrozenFallDamage(EntityDamageEvent event) {
      Entity var3 = event.getEntity();
      if (var3 instanceof Player player) {
         if (this.frozenAt.containsKey(player.getUniqueId())) {
            if (event.getCause() == DamageCause.FALL) {
               event.setCancelled(true);
            }

         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      UUID uid = event.getPlayer().getUniqueId();
      this.cooldowns.remove(uid);
      this.frozenAt.remove(uid);
   }

   public void triggerAbility(Player caster) {
      UUID uid = caster.getUniqueId();
      long now = System.currentTimeMillis();
      Long expiry = (Long)this.cooldowns.get(uid);
      if (expiry == null || expiry <= now) {
         LivingEntity target = this.findTarget(caster, (double)40.0F);
         if (target != null) {
            if (!this.frozenAt.containsKey(target.getUniqueId())) {
               this.cooldowns.put(uid, now + 45000L);
               if (target instanceof Player) {
                  Player playerTarget = (Player)target;
                  this.freezeTarget(caster, playerTarget);
               } else {
                  caster.sendMessage(Component.text("No player target found.", TextColor.color(16733525)));
               }
            }
         }
      }
   }

   private void freezeTarget(Player caster, final Player target) {
      Location loc = target.getLocation().clone();
      target.setVelocity(new Vector(0, 0, 0));
      this.frozenAt.put(target.getUniqueId(), loc.clone());
      target.setFreezeTicks(140);
      Location footLoc = loc.clone().add((double)0.0F, (double)0.0F, (double)0.0F);
      Location chestLoc = loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F);
      final BlockDisplay lowerBlock = this.spawnIceDisplay(footLoc);
      final BlockDisplay upperBlock = this.spawnIceDisplay(chestLoc);
      loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 1.0F, 0.5F);
      loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 40, 0.4, 0.8, 0.4, 0.05);
      (new BukkitRunnable() {
         int ticks = 0;

         public void run() {
            this.ticks += 2;
            if (target.isOnline() && this.ticks < 120) {
               target.setFreezeTicks(140);
               target.setVelocity(new Vector(0, 0, 0));
            } else {
               ColdSoulListener.this.thaw(target, lowerBlock, upperBlock);
               this.cancel();
            }
         }
      }).runTaskTimer(this.plugin, 2L, 2L);
   }

   private void thaw(Player target, BlockDisplay lower, BlockDisplay upper) {
      this.frozenAt.remove(target.getUniqueId());
      lower.remove();
      upper.remove();
      if (target.isOnline()) {
         target.setFreezeTicks(0);
         target.getLocation().getWorld().spawnParticle(Particle.SNOWFLAKE, target.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, 0.3, 0.6, 0.3, 0.02);
      }

   }

   private BlockDisplay spawnIceDisplay(Location loc) {
      return (BlockDisplay)loc.getWorld().spawn(loc, BlockDisplay.class, (display) -> {
         display.setBlock(Bukkit.createBlockData(Material.ICE));
         display.setPersistent(false);
         Transformation t = display.getTransformation();
         t.getScale().set(0.95F, 1.0F, 0.95F);
         t.getTranslation().set(-0.475F, 0.0F, -0.475F);
         display.setTransformation(t);
      });
   }

   private LivingEntity findTarget(Player caster, double radius) {
      TargetMode mode = this.plugin.getTargetModeManager().getMode(caster);
      LivingEntity nearest = null;
      double nearestDist = Double.MAX_VALUE;

      for(Entity entity : caster.getWorld().getNearbyEntities(caster.getLocation(), radius, radius, radius)) {
         if (entity instanceof LivingEntity le) {
            if (!entity.equals(caster) && (mode != TargetMode.PLAYERS || entity instanceof Player) && (mode != TargetMode.MOBS || TargetModeManager.isHostileMob(entity))) {
               double dist = caster.getLocation().distanceSquared(entity.getLocation());
               if (!(dist > radius * radius) && caster.hasLineOfSight(le) && dist < nearestDist) {
                  nearestDist = dist;
                  nearest = le;
               }
            }
         }
      }

      return nearest;
   }

   public void triggerPassive(Player player) {
      player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 1, false, true, true));
      player.setFreezeTicks(200);
   }

   public Map<UUID, Long> getCooldowns() {
      return this.cooldowns;
   }

   public static long getCooldownMs() {
      return 45000L;
   }
}
