package me.ytdarkguy.shadesmp;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class DarkSoulListener implements Listener {
   private static final long COOLDOWN_MS = 60000L;
   private static final int PASSIVE_CHANCE = 10;
   private static final int PASSIVE_BLIND_TICKS = 100;
   private static final int SHROUD_TICKS = 160;
   private static final double DAMAGE_REDUCTION = 0.4;
   private static final TextColor COLOR = TextColor.color(5444514);
   private final ShadeSMP plugin;
   private final Map<UUID, Long> cooldowns = new HashMap();
   private final Set<UUID> inShroud = new HashSet();
   private final Random random = new Random();

   public DarkSoulListener(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onHit(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         if (this.plugin.getSoulManager().getSoul(attacker) == PlayerSoul.DARK_SOUL) {
            Entity var4 = event.getEntity();
            if (var4 instanceof Player) {
               Player target = (Player)var4;
               if (this.random.nextInt(100) < 10) {
                  target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0, false, true, true));
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onShroudAttack(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         if (this.inShroud.contains(attacker.getUniqueId())) {
            event.setDamage(event.getDamage() * 0.6);
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onShroudDamage(EntityDamageEvent event) {
      Entity var3 = event.getEntity();
      if (var3 instanceof Player player) {
         if (this.inShroud.contains(player.getUniqueId())) {
            event.setCancelled(true);
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSwapHandTrigger(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.DARK_SOUL) {
         event.setCancelled(true);
         this.triggerAbility(player);
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      UUID uid = event.getPlayer().getUniqueId();
      this.cooldowns.remove(uid);
      this.inShroud.remove(uid);
   }

   public void triggerAbility(Player player) {
      UUID uid = player.getUniqueId();
      long now = System.currentTimeMillis();
      Long expiry = (Long)this.cooldowns.get(uid);
      if (expiry == null || expiry <= now) {
         if (!this.inShroud.contains(uid)) {
            this.cooldowns.put(uid, now + 60000L);
            this.activateShroud(player);
         }
      }
   }

   private void activateShroud(final Player player) {
      UUID uid = player.getUniqueId();
      this.inShroud.add(uid);
      player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 170, 0, false, false, false));
      player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 0.6F);
      (new BukkitRunnable() {
         int elapsed = 0;

         public void run() {
            this.elapsed += 5;
            if (player.isOnline() && this.elapsed < 160) {
               player.getWorld().spawnParticle(Particle.SMOKE, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 8, 0.4, 0.6, 0.4, 0.02);
               player.getWorld().spawnParticle(Particle.SQUID_INK, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 3, 0.3, (double)0.5F, 0.3, 0.01);
            } else {
               DarkSoulListener.this.endShroud(player);
               this.cancel();
            }
         }
      }).runTaskTimer(this.plugin, 5L, 5L);
   }

   private void endShroud(Player player) {
      this.inShroud.remove(player.getUniqueId());
      player.removePotionEffect(PotionEffectType.INVISIBILITY);
      if (player.isOnline()) {
         player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.8F, 1.2F);
         player.getWorld().spawnParticle(Particle.SMOKE, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, 0.8, (double)0.5F, 0.05);
      }

   }

   public void triggerPassive(Player player) {
      player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0, false, true, true));
   }

   public Map<UUID, Long> getCooldowns() {
      return this.cooldowns;
   }

   public static long getCooldownMs() {
      return 60000L;
   }
}
