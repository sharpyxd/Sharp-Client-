package me.ytdarkguy.shadesmp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;

public class SharpSoulListener implements Listener {
   private static final long COOLDOWN_MS = 60000L;
   private static final int PASSIVE_CHANCE = 10;
   private static final int PASSIVE_STR_TICKS = 100;
   private static final double SEARCH_RADIUS = (double)8.0F;
   private static final double BLAST_RADIUS = (double)5.0F;
   private static final double IMPACT_DAMAGE = (double)8.0F;
   private static final double DROP_HEIGHT = (double)6.0F;
   private static final int SHARD_COUNT = 10;
   private static final TextColor COLOR = TextColor.color(8286917);
   private final ShadeSMP plugin;
   private final Map<UUID, Long> cooldowns = new HashMap();
   private final Random random = new Random();

   public SharpSoulListener(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onHit(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         if (this.plugin.getSoulManager().getSoul(attacker) == PlayerSoul.SHARP_SOUL) {
            if (this.random.nextInt(100) < 10) {
               attacker.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 100, 2, false, true, true));
            }

         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSwapHandTrigger(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.SHARP_SOUL) {
         event.setCancelled(true);
         this.triggerAbility(player);
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.cooldowns.remove(event.getPlayer().getUniqueId());
   }

   public void triggerAbility(Player caster) {
      UUID uid = caster.getUniqueId();
      long now = System.currentTimeMillis();
      Long expiry = (Long)this.cooldowns.get(uid);
      if (expiry == null || expiry <= now) {
         LivingEntity target = this.findNearestEntity(caster, (double)8.0F);
         if (target != null) {
            this.cooldowns.put(uid, now + 60000L);
            this.dropBlade(caster, target);
         }
      }
   }

   private void dropBlade(final Player caster, LivingEntity target) {
      final Location impactLoc = target.getLocation().clone();
      final World world = impactLoc.getWorld();
      Location spawnLoc = impactLoc.clone().add((double)0.0F, (double)6.0F, (double)0.0F);
      final Item sword = world.dropItem(spawnLoc, new ItemStack(Material.DIAMOND_SWORD));
      sword.setPickupDelay(Integer.MAX_VALUE);
      sword.setGravity(true);
      sword.setVelocity(new Vector((double)0.0F, -1.8, (double)0.0F));
      world.playSound(spawnLoc, Sound.ENTITY_ARROW_SHOOT, 0.8F, 0.4F);
      (new BukkitRunnable() {
         int ticks = 0;

         public void run() {
            ++this.ticks;
            if (!sword.isDead() && sword.isValid()) {
               if (this.ticks % 2 == 0) {
                  world.spawnParticle(Particle.CRIT, sword.getLocation(), 3, 0.05, 0.05, 0.05, 0.1);
               }

               Location swordLoc = sword.getLocation();
               Block below = swordLoc.clone().subtract((double)0.0F, 0.3, (double)0.0F).getBlock();
               boolean hitGround = !below.getType().isAir() && below.getType().isSolid() && swordLoc.getY() <= impactLoc.getY() + (double)1.5F;
               if (hitGround || this.ticks >= 30) {
                  sword.remove();
                  this.cancel();
                  SharpSoulListener.this.triggerImpact(caster, impactLoc);
               }

            } else {
               this.cancel();
            }
         }
      }).runTaskTimer(this.plugin, 2L, 1L);
   }

   private void triggerImpact(Player caster, Location impact) {
      World world = impact.getWorld();

      for(Entity entity : world.getNearbyEntities(impact, (double)5.0F, (double)5.0F, (double)5.0F)) {
         if (entity instanceof LivingEntity le) {
            if (!entity.equals(caster)) {
               double newHp = Math.max((double)0.0F, le.getHealth() - (double)8.0F);
               le.setHealth(newHp);
               le.setNoDamageTicks(0);
               if (entity instanceof Player) {
                  Player var9 = (Player)entity;
               }
            }
         }
      }

      world.spawnParticle(Particle.SWEEP_ATTACK, impact.clone().add((double)0.0F, 0.1, (double)0.0F), 20, (double)1.5F, 0.1, (double)1.5F, (double)0.0F);
      world.spawnParticle(Particle.CRIT, impact.clone().add((double)0.0F, (double)0.5F, (double)0.0F), 40, (double)2.0F, (double)0.5F, (double)2.0F, 0.3);
      world.spawnParticle(Particle.BLOCK, impact.clone().add((double)0.0F, 0.1, (double)0.0F), 80, (double)2.0F, 0.1, (double)2.0F, (double)0.5F, this.getGroundBlock(impact).getBlockData());
      world.playSound(impact, Sound.ENTITY_ZOMBIE_ATTACK_IRON_DOOR, 1.2F, 0.6F);
      world.playSound(impact, Sound.BLOCK_STONE_BREAK, 1.0F, 0.8F);
      world.playSound(impact, Sound.ENTITY_GENERIC_EXPLODE, 0.4F, 1.8F);
      this.spawnGroundCrack(impact);
   }

   private void spawnGroundCrack(Location impact) {
      World world = impact.getWorld();
      Block groundBlock = this.getGroundBlock(impact);
      Material groundMat = groundBlock.getType().isSolid() ? groundBlock.getType() : Material.STONE;
      final List<BlockDisplay> shards = new ArrayList();

      for(int i = 0; i < 10; ++i) {
         double angle = (Math.PI / 5D) * (double)i;
         double dist = 0.3 + this.random.nextDouble() * 0.9;
         double dx = Math.cos(angle) * dist;
         double dz = Math.sin(angle) * dist;
         Location sLoc = impact.clone().add(dx, 0.01, dz);
         BlockDisplay bd = (BlockDisplay)world.spawn(sLoc, BlockDisplay.class, (display) -> {
            display.setBlock(Bukkit.createBlockData(groundMat));
            display.setPersistent(false);
            display.setInterpolationDuration(0);
            Transformation t = display.getTransformation();
            t.getScale().set(0.35F, 0.08F, 0.35F);
            t.getTranslation().set(-0.175F, 0.0F, -0.175F);
            display.setTransformation(t);
         });
         shards.add(bd);
      }

      (new BukkitRunnable() {
         int phase = 0;

         public void run() {
            ++this.phase;
            if (this.phase == 1) {
               for(int i = 0; i < shards.size(); ++i) {
                  BlockDisplay bd = (BlockDisplay)shards.get(i);
                  double angle = (Math.PI / 5D) * (double)i;
                  float ox = (float)(Math.cos(angle) * 0.6);
                  float oz = (float)(Math.sin(angle) * 0.6);
                  bd.setInterpolationDelay(0);
                  bd.setInterpolationDuration(8);
                  Transformation t = bd.getTransformation();
                  t.getScale().set(0.4F, 0.12F, 0.4F);
                  t.getTranslation().set(ox - 0.2F, 0.05F, oz - 0.2F);
                  bd.setTransformation(t);
               }
            } else if (this.phase == 10) {
               for(BlockDisplay bd : shards) {
                  bd.setInterpolationDelay(0);
                  bd.setInterpolationDuration(8);
                  Transformation t = bd.getTransformation();
                  t.getScale().set(0.01F, 0.01F, 0.01F);
                  t.getTranslation().set(0.0F, 0.0F, 0.0F);
                  bd.setTransformation(t);
               }
            } else if (this.phase == 20) {
               shards.forEach(Entity::remove);
               this.cancel();
            }

         }
      }).runTaskTimer(this.plugin, 1L, 1L);
   }

   private Block getGroundBlock(Location loc) {
      Block b = loc.getBlock();

      for(int i = 0; i < 5; ++i) {
         if (b.getType().isSolid()) {
            return b;
         }

         b = b.getRelative(0, -1, 0);
      }

      return loc.getBlock();
   }

   private LivingEntity findNearestEntity(Player caster, double radius) {
      TargetMode mode = this.plugin.getTargetModeManager().getMode(caster);
      LivingEntity nearest = null;
      double nearestDist = Double.MAX_VALUE;

      for(Entity entity : caster.getWorld().getNearbyEntities(caster.getLocation(), radius, radius, radius)) {
         if (entity instanceof LivingEntity le) {
            if (!entity.equals(caster) && (mode != TargetMode.PLAYERS || entity instanceof Player) && (mode != TargetMode.MOBS || TargetModeManager.isHostileMob(entity))) {
               double dist = caster.getLocation().distanceSquared(entity.getLocation());
               if (!(dist > radius * radius) && dist < nearestDist) {
                  nearestDist = dist;
                  nearest = le;
               }
            }
         }
      }

      return nearest;
   }

   public void triggerPassive(Player player) {
      player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 100, 2, false, true, true));
   }

   public Map<UUID, Long> getCooldowns() {
      return this.cooldowns;
   }

   public static long getCooldownMs() {
      return 60000L;
   }
}
