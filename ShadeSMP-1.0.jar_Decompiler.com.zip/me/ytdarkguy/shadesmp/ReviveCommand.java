package me.ytdarkguy.shadesmp;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class ReviveCommand implements CommandExecutor, TabCompleter {
   private final ShadeSMP plugin;
   private final NamespacedKey soulOwnerKey;

   public ReviveCommand(ShadeSMP plugin) {
      this.plugin = plugin;
      this.soulOwnerKey = new NamespacedKey(plugin, "soul_owner");
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.isOp()) {
         return true;
      } else if (args.length != 1) {
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         if (target != null && target.isOnline()) {
            if (target.getGameMode() != GameMode.SPECTATOR) {
               return true;
            } else {
               this.removeSoulItem(target.getUniqueId());
               Player senderPlayer = sender instanceof Player ? (Player)sender : null;
               if (senderPlayer != null) {
                  target.teleport(senderPlayer.getLocation());
               }

               target.setGameMode(GameMode.SURVIVAL);
               return true;
            }
         } else {
            return true;
         }
      }
   }

   private void removeSoulItem(UUID ownerUUID) {
      String uuidStr = ownerUUID.toString();

      for(Player p : Bukkit.getOnlinePlayers()) {
         for(ItemStack item : p.getInventory().getContents()) {
            if (this.isSoulOf(item, uuidStr)) {
               p.getInventory().remove(item);
               return;
            }
         }
      }

      for(World world : Bukkit.getWorlds()) {
         for(Entity entity : world.getEntities()) {
            if (entity instanceof Item droppedItem) {
               if (this.isSoulOf(droppedItem.getItemStack(), uuidStr)) {
                  droppedItem.remove();
                  return;
               }
            }
         }
      }

   }

   private boolean isSoulOf(ItemStack item, String uuidStr) {
      if (item != null && item.hasItemMeta()) {
         PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
         return !pdc.has(this.soulOwnerKey, PersistentDataType.STRING) ? false : uuidStr.equals(pdc.get(this.soulOwnerKey, PersistentDataType.STRING));
      } else {
         return false;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.isOp()) {
         return List.of();
      } else if (args.length == 1) {
         List<String> names = new ArrayList();

         for(Player p : Bukkit.getOnlinePlayers()) {
            if (p.getGameMode() == GameMode.SPECTATOR && p.getName().toLowerCase().startsWith(args[0].toLowerCase())) {
               names.add(p.getName());
            }
         }

         return names;
      } else {
         return List.of();
      }
   }
}
