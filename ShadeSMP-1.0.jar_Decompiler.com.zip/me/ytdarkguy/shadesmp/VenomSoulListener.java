package me.ytdarkguy.shadesmp;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class VenomSoulListener implements Listener {
   private static final double PULL_RADIUS = (double)40.0F;
   private static final long COOLDOWN_MS = 30000L;
   private static final int POISON_CHANCE = 10;
   private static final int POISON_TICKS = 60;
   private static final TextColor COLOR = TextColor.color(5614165);
   private final ShadeSMP plugin;
   private final Map<UUID, Long> cooldowns = new HashMap();
   private final Random random = new Random();

   public VenomSoulListener(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onHit(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         if (this.plugin.getSoulManager().getSoul(attacker) == PlayerSoul.VENOM_SOUL) {
            if (this.random.nextInt(100) < 10) {
               event.getEntity().addScoreboardTag("_venom_hit");
               Entity var4 = event.getEntity();
               if (var4 instanceof LivingEntity) {
                  LivingEntity le = (LivingEntity)var4;
                  le.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60, 0, false, true, true));
               }
            }

         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSwapHandTrigger(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.VENOM_SOUL) {
         event.setCancelled(true);
         this.triggerAbility(player);
      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.cooldowns.remove(event.getPlayer().getUniqueId());
   }

   public void triggerAbility(Player caster) {
      UUID uid = caster.getUniqueId();
      long now = System.currentTimeMillis();
      Long expiry = (Long)this.cooldowns.get(uid);
      if (expiry != null && expiry > now) {
         long secs = (long)Math.ceil((double)(expiry - now) / (double)1000.0F);
      } else {
         LivingEntity target = this.findTarget(caster);
         if (target != null) {
            this.cooldowns.put(uid, now + 30000L);
            Vector pull = caster.getLocation().toVector().subtract(target.getLocation().toVector()).normalize().multiply(2.2).setY((double)0.5F);
            target.setVelocity(pull);
            this.spawnVineParticles(caster.getLocation(), target.getLocation());
            caster.playSound(caster.getLocation(), Sound.BLOCK_VINE_PLACE, 1.0F, 0.8F);
            target.getWorld().playSound(target.getLocation(), Sound.ENTITY_SPIDER_AMBIENT, 1.0F, 0.6F);
         }
      }
   }

   private LivingEntity findTarget(Player caster) {
      TargetMode mode = this.plugin.getTargetModeManager().getMode(caster);
      LivingEntity nearest = null;
      double nearestDist = Double.MAX_VALUE;

      for(Entity entity : caster.getWorld().getNearbyEntities(caster.getLocation(), (double)40.0F, (double)40.0F, (double)40.0F)) {
         if (entity instanceof LivingEntity le) {
            if (!entity.equals(caster) && (mode != TargetMode.PLAYERS || entity instanceof Player) && (mode != TargetMode.MOBS || TargetModeManager.isHostileMob(entity))) {
               double dist = caster.getLocation().distanceSquared(entity.getLocation());
               if (!(dist > (double)1600.0F) && caster.hasLineOfSight(le) && dist < nearestDist) {
                  nearestDist = dist;
                  nearest = le;
               }
            }
         }
      }

      return nearest;
   }

   private void spawnVineParticles(Location from, Location to) {
      Vector step = to.toVector().subtract(from.toVector());
      int steps = (int)(step.length() * (double)2.0F);
      if (steps != 0) {
         step = step.multiply((double)1.0F / (double)steps);
         Location current = from.clone();

         for(int i = 0; i < steps; ++i) {
            current.add(step);
            current.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, current, 1, 0.1, 0.1, 0.1, (double)0.0F);
         }

      }
   }

   public void triggerPassive(Player player) {
      player.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60, 0, false, true, true));
   }

   public Map<UUID, Long> getCooldowns() {
      return this.cooldowns;
   }

   public static long getCooldownMs() {
      return 30000L;
   }
}
