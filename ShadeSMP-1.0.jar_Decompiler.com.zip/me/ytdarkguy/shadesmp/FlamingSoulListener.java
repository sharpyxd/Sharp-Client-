package me.ytdarkguy.shadesmp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class FlamingSoulListener implements Listener {
   private static final long COOLDOWN_MS = 60000L;
   private static final double FIRE_BONUS_MULT = 1.3;
   private static final double CURSE_FIRE_MULT = (double)1.5F;
   private static final int CURSE_DURATION = 160;
   private static final double SEARCH_RADIUS = (double)10.0F;
   private static final int ARMOUR_DAMAGE = 20;
   private static final TextColor COLOR = TextColor.color(14628663);
   private final ShadeSMP plugin;
   private final Map<UUID, Long> cooldowns = new HashMap();
   private final Map<UUID, Location> cursed = new HashMap();
   private final Random random = new Random();
   private static final EquipmentSlot[] ARMOUR_SLOTS;

   public FlamingSoulListener(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.FLAMING_SOUL) {
         this.applyFireResistance(player);
      }

   }

   public void tickPlayer(Player player) {
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.FLAMING_SOUL) {
         PotionEffect current = player.getPotionEffect(PotionEffectType.FIRE_RESISTANCE);
         if (current == null || current.getDuration() < 20) {
            this.applyFireResistance(player);
         }

      }
   }

   private void applyFireResistance(Player player) {
      player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 20, 0, false, false, false));
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onFireDamageBonus(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         if (this.plugin.getSoulManager().getSoul(attacker) == PlayerSoul.FLAMING_SOUL) {
            if (attacker.getFireTicks() > 0) {
               event.setDamage(event.getDamage() * 1.3);
            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSwapHandTrigger(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.FLAMING_SOUL) {
         event.setCancelled(true);
         this.triggerAbility(player);
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onCursedFireDamage(EntityDamageEvent event) {
      UUID uid = event.getEntity().getUniqueId();
      if (this.cursed.containsKey(uid)) {
         EntityDamageEvent.DamageCause cause = event.getCause();
         if (cause == DamageCause.FIRE || cause == DamageCause.FIRE_TICK || cause == DamageCause.LAVA) {
            event.setDamage(event.getDamage() * (double)1.5F);
            Entity var5 = event.getEntity();
            if (var5 instanceof Player) {
               Player target = (Player)var5;
               this.damageRandomArmour(target);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOW
   )
   public void onCursedCombust(EntityCombustEvent event) {
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      UUID uid = event.getPlayer().getUniqueId();
      this.cooldowns.remove(uid);
      this.removeLava(uid);
      this.cursed.remove(uid);
   }

   public void triggerAbility(Player caster) {
      UUID uid = caster.getUniqueId();
      long now = System.currentTimeMillis();
      Long expiry = (Long)this.cooldowns.get(uid);
      if (expiry == null || expiry <= now) {
         LivingEntity target = this.findNearestEntity(caster, (double)10.0F);
         if (target != null) {
            if (!this.cursed.containsKey(target.getUniqueId())) {
               this.cooldowns.put(uid, now + 60000L);
               this.applyCurse(caster, target);
            }
         }
      }
   }

   private void applyCurse(Player caster, final LivingEntity target) {
      final UUID tuid = target.getUniqueId();
      Location lavaLoc = target.getLocation().clone();
      lavaLoc.setY(Math.floor(lavaLoc.getY()));
      this.placeLava(tuid, lavaLoc);
      target.setFireTicks(Integer.MAX_VALUE);
      lavaLoc.getWorld().spawnParticle(Particle.LAVA, lavaLoc.clone().add((double)0.0F, (double)0.5F, (double)0.0F), 20, 0.4, 0.4, 0.4, 0.1);
      lavaLoc.getWorld().playSound(lavaLoc, Sound.BLOCK_LAVA_POP, 1.0F, 0.8F);
      if (target instanceof Player var5) {
         ;
      }

      (new BukkitRunnable() {
         int elapsed = 0;

         public void run() {
            this.elapsed += 4;
            if (FlamingSoulListener.this.isAlive(target) && this.elapsed < 160) {
               target.setFireTicks(100);
               Location newLoc = target.getLocation().clone();
               newLoc.setY(Math.floor(newLoc.getY()));
               Location old = (Location)FlamingSoulListener.this.cursed.get(tuid);
               if (old != null && !FlamingSoulListener.this.blockEqual(old, newLoc)) {
                  FlamingSoulListener.this.removeLava(tuid);
                  FlamingSoulListener.this.placeLava(tuid, newLoc);
               }

               newLoc.getWorld().spawnParticle(Particle.LAVA, newLoc.clone().add((double)0.0F, 0.3, (double)0.0F), 2, 0.3, 0.1, 0.3, (double)0.0F);
               newLoc.getWorld().spawnParticle(Particle.FLAME, newLoc.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 3, 0.2, 0.3, 0.2, 0.05);
            } else {
               FlamingSoulListener.this.endCurse(target);
               this.cancel();
            }
         }
      }).runTaskTimer(this.plugin, 4L, 4L);
   }

   private void endCurse(LivingEntity target) {
      UUID tuid = target.getUniqueId();
      this.removeLava(tuid);
      this.cursed.remove(tuid);
      if (this.isAlive(target)) {
         target.setFireTicks(0);
         if (target instanceof Player) {
            Player var3 = (Player)target;
         }

         target.getLocation().getWorld().spawnParticle(Particle.SMOKE, target.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 15, 0.3, (double)0.5F, 0.3, 0.05);
      }

   }

   private void placeLava(UUID uid, Location loc) {
      Block block = loc.getBlock();
      if (!block.getType().isAir() && block.getType().isSolid()) {
         loc = loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F);
         block = loc.getBlock();
      }

      if (block.getType().isAir()) {
         block.setType(Material.LAVA);
         this.cursed.put(uid, loc.clone());
      }
   }

   private void removeLava(UUID uid) {
      Location loc = (Location)this.cursed.get(uid);
      if (loc != null) {
         Block block = loc.getBlock();
         if (block.getType() == Material.LAVA) {
            block.setType(Material.AIR);
         }

      }
   }

   private void damageRandomArmour(Player player) {
      List<EquipmentSlot> worn = new ArrayList();

      for(EquipmentSlot slot : ARMOUR_SLOTS) {
         ItemStack item = player.getInventory().getItem(slot);
         if (item != null && item.getType() != Material.AIR && item.getItemMeta() instanceof Damageable) {
            worn.add(slot);
         }
      }

      if (!worn.isEmpty()) {
         EquipmentSlot chosen = (EquipmentSlot)worn.get(this.random.nextInt(worn.size()));
         ItemStack item = player.getInventory().getItem(chosen);
         if (item != null) {
            ItemMeta meta = item.getItemMeta();
            if (meta instanceof Damageable) {
               Damageable dmgMeta = (Damageable)meta;
               short maxDurability = item.getType().getMaxDurability();
               int currentDamage = dmgMeta.getDamage();
               int newDamage = currentDamage + 20;
               if (newDamage >= maxDurability) {
                  player.getInventory().setItem(chosen, new ItemStack(Material.AIR));
                  player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0F, 1.0F);
               } else {
                  dmgMeta.setDamage(newDamage);
                  item.setItemMeta(dmgMeta);
               }

            }
         }
      }
   }

   private LivingEntity findNearestEntity(Player caster, double radius) {
      TargetMode mode = this.plugin.getTargetModeManager().getMode(caster);
      LivingEntity nearest = null;
      double nearestDist = Double.MAX_VALUE;

      for(Entity entity : caster.getWorld().getNearbyEntities(caster.getLocation(), radius, radius, radius)) {
         if (entity instanceof LivingEntity le) {
            if (!entity.equals(caster) && (mode != TargetMode.PLAYERS || entity instanceof Player) && (mode != TargetMode.MOBS || TargetModeManager.isHostileMob(entity))) {
               double dist = caster.getLocation().distanceSquared(entity.getLocation());
               if (!(dist > radius * radius) && dist < nearestDist) {
                  nearestDist = dist;
                  nearest = le;
               }
            }
         }
      }

      return nearest;
   }

   private boolean isAlive(LivingEntity entity) {
      if (entity.isValid() && !entity.isDead()) {
         if (entity instanceof Player) {
            Player p = (Player)entity;
            return p.isOnline();
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean blockEqual(Location a, Location b) {
      return a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
   }

   private String nameOf(LivingEntity entity) {
      String var10000;
      if (entity instanceof Player p) {
         var10000 = p.getName();
      } else {
         var10000 = entity.getType().name();
      }

      return var10000;
   }

   public void triggerPassive(Player player) {
      this.applyFireResistance(player);
   }

   public Map<UUID, Long> getCooldowns() {
      return this.cooldowns;
   }

   public static long getCooldownMs() {
      return 60000L;
   }

   static {
      ARMOUR_SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   }
}
