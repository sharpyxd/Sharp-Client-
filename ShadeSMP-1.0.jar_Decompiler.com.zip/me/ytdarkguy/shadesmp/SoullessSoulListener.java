package me.ytdarkguy.shadesmp;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class SoullessSoulListener implements Listener {
   private static final long COOLDOWN_MS = 150000L;
   private static final int PASSIVE_CHANCE = 10;
   private static final int PASSIVE_WEAK_TICKS = 60;
   private static final int CURSE_DURATION_TICKS = 1200;
   private static final double ABILITY_RADIUS = (double)16.0F;
   static final TextColor COLOR = TextColor.color(2829099);
   private final ShadeSMP plugin;
   private final Map<UUID, Long> cooldowns = new HashMap();
   private final Map<UUID, PlayerSoul> cursedSouls = new HashMap();
   private final Random random = new Random();

   public SoullessSoulListener(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onHit(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         if (this.plugin.getSoulManager().getSoul(attacker) == PlayerSoul.SOULLESS) {
            Entity var4 = event.getEntity();
            if (var4 instanceof Player) {
               Player target = (Player)var4;
               if (this.random.nextInt(100) < 10) {
                  target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0, false, true, true));
               }

               if (this.cursedSouls.containsKey(target.getUniqueId()) && this.random.nextInt(100) < 10) {
                  target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0, false, true, true));
               }

            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSwapHandTrigger(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.SOULLESS) {
         event.setCancelled(true);
         this.triggerAbility(player);
      }
   }

   public void triggerAbility(Player caster) {
      UUID casterUUID = caster.getUniqueId();
      long now = System.currentTimeMillis();
      if (!this.cursedSouls.containsKey(casterUUID)) {
         Long expiry = (Long)this.cooldowns.get(casterUUID);
         if (expiry != null && expiry > now) {
            long remaining = (expiry - now) / 1000L;
         } else {
            LivingEntity target = this.findNearestPlayer(caster, (double)16.0F);
            if (target != null) {
               this.cooldowns.put(casterUUID, now + 150000L);
               if (target instanceof Player) {
                  Player playerTarget = (Player)target;
                  this.applyCurse(caster, playerTarget);
               } else {
                  caster.sendMessage(Component.text("No player target found.", TextColor.color(16733525)));
               }
            }
         }
      }
   }

   private void applyCurse(Player caster, final Player target) {
      final UUID targetUUID = target.getUniqueId();
      PlayerSoul realSoul = this.plugin.getSoulManager().getSoul(target);
      this.cursedSouls.put(targetUUID, realSoul);
      this.plugin.getSoulManager().setSoulSilent(target, PlayerSoul.SOULLESS);
      target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 1200, 0, false, true, true));
      caster.playSound(caster.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5F, 1.8F);
      target.playSound(target.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5F, 1.8F);
      this.spawnCurseParticles(caster, target);
      (new BukkitRunnable() {
         public void run() {
            if (SoullessSoulListener.this.cursedSouls.containsKey(targetUUID)) {
               PlayerSoul restore = (PlayerSoul)SoullessSoulListener.this.cursedSouls.remove(targetUUID);
               if (restore != null) {
                  SoullessSoulListener.this.plugin.getSoulManager().setSoulSilent(target, restore);
               }

            }
         }
      }).runTaskLater(this.plugin, 1200L);
   }

   private void spawnCurseParticles(Player caster, final Player target) {
      final Location from = caster.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
      Location to = target.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
      final World world = caster.getWorld();
      final double dx = to.getX() - from.getX();
      final double dy = to.getY() - from.getY();
      final double dz = to.getZ() - from.getZ();
      double dist = from.distance(to);
      final int steps = Math.max(1, (int)(dist * (double)4.0F));
      (new BukkitRunnable() {
         int tick = 0;

         public void run() {
            if (this.tick >= steps) {
               SoullessSoulListener.this.spawnCurseBurst(target.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), world);
               this.cancel();
            } else {
               double t = (double)this.tick / (double)steps;
               double px = from.getX() + dx * t;
               double py = from.getY() + dy * t;
               double pz = from.getZ() + dz * t;
               double wave = Math.sin((double)this.tick * 0.55) * 0.55;
               double perp = Math.cos((double)this.tick * 0.55) * 0.55;
               double len2 = Math.sqrt(dx * dx + dz * dz);
               double ox = len2 > (double)0.0F ? -dz / len2 * wave : (double)0.0F;
               double oz = len2 > (double)0.0F ? dx / len2 * wave : (double)0.0F;
               double oy = perp * 0.4;
               Location waveLoc = new Location(world, px + ox, py + oy, pz + oz);
               world.spawnParticle(Particle.SOUL, waveLoc, 2, 0.08, 0.08, 0.08, (double)0.0F);
               world.spawnParticle(Particle.SQUID_INK, waveLoc, 1, 0.05, 0.05, 0.05, 0.02);
               if (this.tick % 2 == 0) {
                  world.spawnParticle(Particle.ASH, waveLoc, 2, 0.1, 0.1, 0.1, 0.01);
               }

               if (this.tick % 5 == 0) {
                  world.spawnParticle(Particle.SOUL_FIRE_FLAME, waveLoc, 1, 0.05, 0.05, 0.05, (double)0.0F);
               }

               ++this.tick;
            }
         }
      }).runTaskTimer(this.plugin, 0L, 1L);
   }

   private void spawnCurseBurst(Location loc, World world) {
      for(int i = 0; i < 24; ++i) {
         double angle = 0.2617993877991494 * (double)i;
         double radius = 0.9;
         double bx = Math.cos(angle) * radius;
         double bz = Math.sin(angle) * radius;
         Location ring = loc.clone().add(bx, (double)0.0F, bz);
         world.spawnParticle(Particle.SOUL, ring, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
         world.spawnParticle(Particle.SOUL_FIRE_FLAME, ring, 1, (double)0.0F, 0.05, (double)0.0F, (double)0.0F);
      }

      world.spawnParticle(Particle.SQUID_INK, loc, 20, 0.3, 0.3, 0.3, 0.06);
      world.spawnParticle(Particle.ASH, loc, 30, 0.4, (double)0.5F, 0.4, 0.04);
      world.spawnParticle(Particle.SOUL, loc, 12, 0.2, 0.4, 0.2, 0.02);
      world.spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 8, 0.15, 0.3, 0.15, (double)0.0F);
      world.spawnParticle(Particle.SMOKE, loc, 10, 0.2, 0.1, 0.2, 0.02);
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      UUID uuid = player.getUniqueId();
      this.cursedSouls.remove(uuid);
      this.cooldowns.remove(uuid);
   }

   private LivingEntity findNearestPlayer(Player caster, double radius) {
      TargetMode mode = this.plugin.getTargetModeManager().getMode(caster);
      LivingEntity nearest = null;
      double nearestDist = radius * radius;

      for(Entity entity : caster.getWorld().getNearbyEntities(caster.getLocation(), radius, radius, radius)) {
         if (entity instanceof LivingEntity le) {
            if (!entity.equals(caster) && (mode != TargetMode.PLAYERS || entity instanceof Player) && (mode != TargetMode.MOBS || TargetModeManager.isHostileMob(entity))) {
               double dist = entity.getLocation().distanceSquared(caster.getLocation());
               if (dist < nearestDist) {
                  nearestDist = dist;
                  nearest = le;
               }
            }
         }
      }

      return nearest;
   }

   public void triggerPassive(Player player) {
      player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0, false, true, true));
   }

   public Map<UUID, Long> getCooldowns() {
      return this.cooldowns;
   }

   public static long getCooldownMs() {
      return 150000L;
   }
}
