package me.ytdarkguy.shadesmp;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class SelfSoulCommand implements CommandExecutor, TabCompleter {
   private static final List<String> SOUL_NAMES = (List)Arrays.stream(PlayerSoul.values()).map((s) -> s.key().toLowerCase(Locale.ROOT)).collect(Collectors.toList());
   private static final List<String> MODES = List.of("passive", "ability");
   private final ShadeSMP plugin;

   public SelfSoulCommand(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!player.isOp()) {
            return true;
         } else if (args.length < 2) {
            return true;
         } else {
            PlayerSoul soul = PlayerSoul.fromKey(args[0].toUpperCase(Locale.ROOT));
            if (soul == null) {
               return true;
            } else {
               String mode = args[1].toLowerCase(Locale.ROOT);
               if (!mode.equals("passive") && !mode.equals("ability")) {
                  return true;
               } else {
                  boolean isPassive = mode.equals("passive");
                  if (isPassive) {
                     this.triggerPassive(player, soul);
                  } else {
                     this.triggerAbility(player, soul);
                  }

                  return true;
               }
            }
         }
      } else {
         return true;
      }
   }

   private void triggerPassive(Player player, PlayerSoul soul) {
      switch (soul) {
         case VENOM_SOUL -> this.plugin.getVenomSoulListener().triggerPassive(player);
         case QUICKENING -> this.plugin.getQuickeningSoulListener().triggerPassive(player);
         case COLD_SOUL -> this.plugin.getColdSoulListener().triggerPassive(player);
         case DARK_SOUL -> this.plugin.getDarkSoulListener().triggerPassive(player);
         case SHARP_SOUL -> this.plugin.getSharpSoulListener().triggerPassive(player);
         case FLAMING_SOUL -> this.plugin.getFlamingSoulListener().triggerPassive(player);
         case SOULLESS -> this.plugin.getSoullessSoulListener().triggerPassive(player);
      }

   }

   private void triggerAbility(Player player, PlayerSoul soul) {
      switch (soul) {
         case VENOM_SOUL -> this.plugin.getVenomSoulListener().triggerAbility(player);
         case QUICKENING -> this.plugin.getQuickeningSoulListener().triggerAbility(player);
         case COLD_SOUL -> this.plugin.getColdSoulListener().triggerAbility(player);
         case DARK_SOUL -> this.plugin.getDarkSoulListener().triggerAbility(player);
         case SHARP_SOUL -> this.plugin.getSharpSoulListener().triggerAbility(player);
         case FLAMING_SOUL -> this.plugin.getFlamingSoulListener().triggerAbility(player);
         case SOULLESS -> this.plugin.getSoullessSoulListener().triggerAbility(player);
      }

   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (sender instanceof Player player) {
         if (player.isOp()) {
            if (args.length == 1) {
               String partial = args[0].toLowerCase(Locale.ROOT);
               return (List)SOUL_NAMES.stream().filter((s) -> s.startsWith(partial)).collect(Collectors.toList());
            }

            if (args.length == 2) {
               String partial = args[1].toLowerCase(Locale.ROOT);
               return (List)MODES.stream().filter((m) -> m.startsWith(partial)).collect(Collectors.toList());
            }

            return List.of();
         }
      }

      return List.of();
   }
}
