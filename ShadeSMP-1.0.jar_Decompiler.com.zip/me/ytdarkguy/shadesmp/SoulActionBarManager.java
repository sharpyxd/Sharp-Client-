package me.ytdarkguy.shadesmp;

import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;

public class SoulActionBarManager {
   private static final int MAX_FILL = 9;
   private static final String ICON_INVIS = "\ue24c";
   private static final String ICON_STRENGTH = "\ue39c";
   private static final String ICON_FROST = "\ue150";
   private static final String ICON_HASTE = "\ue1a4";
   private static final String ICON_EMERALD = "\ue02a";
   private static final String ICON_FIRE = "\ue0fc";
   private static final String ICON_SOULLESS = "\ue000";
   private static final int BAR_INVIS = 58612;
   private static final int BAR_STRENGTH = 58668;
   private static final int BAR_FROST = 58570;
   private static final int BAR_HASTE = 58584;
   private static final int BAR_EMERALD = 58514;
   private static final int BAR_FIRE = 58556;
   private static final int BAR_SOULLESS = 58500;
   private final ShadeSMP plugin;

   public SoulActionBarManager(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   public void update(Player player) {
      PlayerSoul soul = this.plugin.getSoulManager().getSoul(player);
      if (soul != null) {
         String var10000;
         switch (soul) {
            case VENOM_SOUL -> var10000 = "\ue24c";
            case DARK_SOUL -> var10000 = "\ue39c";
            case COLD_SOUL -> var10000 = "\ue150";
            case QUICKENING -> var10000 = "\ue1a4";
            case SHARP_SOUL -> var10000 = "\ue02a";
            case FLAMING_SOUL -> var10000 = "\ue0fc";
            case SOULLESS -> var10000 = "\ue000";
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         String icon = var10000;
         char var7;
         switch (soul) {
            case VENOM_SOUL -> var7 = 58612;
            case DARK_SOUL -> var7 = 58668;
            case COLD_SOUL -> var7 = 58570;
            case QUICKENING -> var7 = 58584;
            case SHARP_SOUL -> var7 = 58514;
            case FLAMING_SOUL -> var7 = 58556;
            case SOULLESS -> var7 = 58500;
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         int barBase = var7;
         switch (soul) {
            case VENOM_SOUL -> var7 = this.fillLevel(player, this.plugin.getVenomSoulListener().getCooldowns(), VenomSoulListener.getCooldownMs());
            case DARK_SOUL -> var7 = this.fillLevel(player, this.plugin.getDarkSoulListener().getCooldowns(), DarkSoulListener.getCooldownMs());
            case COLD_SOUL -> var7 = this.fillLevel(player, this.plugin.getColdSoulListener().getCooldowns(), ColdSoulListener.getCooldownMs());
            case QUICKENING -> var7 = this.fillLevel(player, this.plugin.getQuickeningSoulListener().getCooldowns(), QuickeningSoulListener.getCooldownMs());
            case SHARP_SOUL -> var7 = this.fillLevel(player, this.plugin.getSharpSoulListener().getCooldowns(), SharpSoulListener.getCooldownMs());
            case FLAMING_SOUL -> var7 = this.fillLevel(player, this.plugin.getFlamingSoulListener().getCooldowns(), FlamingSoulListener.getCooldownMs());
            case SOULLESS -> var7 = this.fillLevel(player, this.plugin.getSoullessSoulListener().getCooldowns(), SoullessSoulListener.getCooldownMs());
            default -> var7 = 9;
         }

         int fill = var7;
         String text = icon + (char)(barBase + fill);
         player.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(text));
      }
   }

   private int fillLevel(Player player, Map<UUID, Long> cooldowns, long cooldownMs) {
      long now = System.currentTimeMillis();
      Long expiry = (Long)cooldowns.get(player.getUniqueId());
      if (expiry != null && expiry > now) {
         long remaining = expiry - now;
         double ratio = (double)1.0F - (double)remaining / (double)cooldownMs;
         int fill = (int)Math.round(ratio * (double)9.0F);
         return Math.max(0, Math.min(9, fill));
      } else {
         return 9;
      }
   }
}
