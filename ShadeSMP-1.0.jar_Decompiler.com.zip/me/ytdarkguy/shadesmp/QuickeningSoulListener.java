package me.ytdarkguy.shadesmp;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class QuickeningSoulListener implements Listener {
   private static final long COOLDOWN_MS = 45000L;
   private static final int SURGE_DURATION = 200;
   private static final int SURGE_LEVEL = 4;
   private static final TextColor COLOR = TextColor.color(16777045);
   private final ShadeSMP plugin;
   private final Map<UUID, Long> cooldowns = new HashMap();

   public QuickeningSoulListener(ShadeSMP plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.QUICKENING) {
         this.applyPassiveHaste(player);
      }

   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.cooldowns.remove(event.getPlayer().getUniqueId());
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSwapHandTrigger(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.QUICKENING) {
         event.setCancelled(true);
         this.triggerAbility(player);
      }
   }

   public void tickPlayer(Player player) {
      if (this.plugin.getSoulManager().getSoul(player) == PlayerSoul.QUICKENING) {
         PotionEffect current = player.getPotionEffect(PotionEffectType.HASTE);
         if (current == null || current.getAmplifier() < 4) {
            this.applyPassiveHaste(player);
         }
      }
   }

   public void triggerAbility(final Player player) {
      UUID uid = player.getUniqueId();
      long now = System.currentTimeMillis();
      Long expiry = (Long)this.cooldowns.get(uid);
      if (expiry != null && expiry > now) {
         long secs = (long)Math.ceil((double)(expiry - now) / (double)1000.0F);
      } else {
         this.cooldowns.put(uid, now + 45000L);
         player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 200, 4, false, true, true));
         player.getWorld().spawnParticle(Particle.SWEEP_ATTACK, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 12, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F);
         player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0F, 1.5F);
         (new BukkitRunnable() {
            public void run() {
               if (player.isOnline() && QuickeningSoulListener.this.plugin.getSoulManager().getSoul(player) == PlayerSoul.QUICKENING) {
                  QuickeningSoulListener.this.applyPassiveHaste(player);
               }

            }
         }).runTaskLater(this.plugin, 201L);
      }
   }

   private void applyPassiveHaste(Player player) {
      player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 20, 0, false, false, false));
   }

   public void triggerPassive(Player player) {
      this.applyPassiveHaste(player);
   }

   public Map<UUID, Long> getCooldowns() {
      return this.cooldowns;
   }

   public static long getCooldownMs() {
      return 45000L;
   }
}
