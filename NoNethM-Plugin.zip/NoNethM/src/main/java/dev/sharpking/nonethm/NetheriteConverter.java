package dev.sharpking.nonethm;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;

public class NetheriteConverter {

    private final NoNethM plugin;

    // Full netherite -> diamond material map
    private static final Map<Material, Material> CONVERSION_MAP = new HashMap<>();

    static {
        // Armor
        CONVERSION_MAP.put(Material.NETHERITE_HELMET,      Material.DIAMOND_HELMET);
        CONVERSION_MAP.put(Material.NETHERITE_CHESTPLATE,  Material.DIAMOND_CHESTPLATE);
        CONVERSION_MAP.put(Material.NETHERITE_LEGGINGS,    Material.DIAMOND_LEGGINGS);
        CONVERSION_MAP.put(Material.NETHERITE_BOOTS,       Material.DIAMOND_BOOTS);
        // Tools
        CONVERSION_MAP.put(Material.NETHERITE_SWORD,       Material.DIAMOND_SWORD);
        CONVERSION_MAP.put(Material.NETHERITE_AXE,         Material.DIAMOND_AXE);
        CONVERSION_MAP.put(Material.NETHERITE_PICKAXE,     Material.DIAMOND_PICKAXE);
        CONVERSION_MAP.put(Material.NETHERITE_SHOVEL,      Material.DIAMOND_SHOVEL);
        CONVERSION_MAP.put(Material.NETHERITE_HOE,         Material.DIAMOND_HOE);
        // Block / raw
        CONVERSION_MAP.put(Material.NETHERITE_BLOCK,       Material.DIAMOND_BLOCK);
        CONVERSION_MAP.put(Material.NETHERITE_INGOT,       Material.DIAMOND);
        CONVERSION_MAP.put(Material.NETHERITE_SCRAP,       Material.DIAMOND);
    }

    public NetheriteConverter(NoNethM plugin) {
        this.plugin = plugin;
    }

    public boolean isNetherite(ItemStack item) {
        return item != null && CONVERSION_MAP.containsKey(item.getType());
    }

    /** Returns a converted diamond equivalent preserving enchants, name, lore, amount. */
    public ItemStack convert(ItemStack item) {
        Material diamond = CONVERSION_MAP.get(item.getType());
        if (diamond == null) return item;

        ItemStack converted = new ItemStack(diamond, item.getAmount());

        // Copy meta (enchants, display name, lore, custom model data, etc.)
        ItemMeta oldMeta = item.getItemMeta();
        ItemMeta newMeta = converted.getItemMeta();

        if (oldMeta != null && newMeta != null) {
            // Display name
            if (oldMeta.hasDisplayName()) newMeta.setDisplayName(oldMeta.getDisplayName());
            // Lore
            if (oldMeta.hasLore()) newMeta.setLore(oldMeta.getLore());
            // Custom model data
            if (oldMeta.hasCustomModelData()) newMeta.setCustomModelData(oldMeta.getCustomModelData());
            // Repair cost
            if (oldMeta instanceof org.bukkit.inventory.meta.Repairable r1
                    && newMeta instanceof org.bukkit.inventory.meta.Repairable r2) {
                r2.setRepairCost(r1.getRepairCost());
            }
            converted.setItemMeta(newMeta);
        }

        // Copy enchantments AFTER meta (avoids level cap restrictions)
        for (Map.Entry<Enchantment, Integer> entry : item.getEnchantments().entrySet()) {
            converted.addUnsafeEnchantment(entry.getKey(), entry.getValue());
        }

        return converted;
    }

    public static Map<Material, Material> getConversionMap() {
        return CONVERSION_MAP;
    }
}
