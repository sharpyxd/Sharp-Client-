package dev.sharpking.nonethm;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NoNethMCommand implements CommandExecutor {

    private final NoNethM plugin;

    public NoNethMCommand(NoNethM plugin) {
        this.plugin = plugin;
    }

    private String msg(String key) {
        String prefix = plugin.getConfig().getString("messages.prefix", "[NoNethM] ");
        String raw = plugin.getConfig().getString("messages." + key, "§cMissing message: " + key);
        return colorize(prefix + raw);
    }

    private String msgRaw(String key) {
        return colorize(plugin.getConfig().getString("messages." + key, ""));
    }

    private String colorize(String s) {
        return s.replace("&", "§");
    }

    private String resolve(String key, String placeholder, String value) {
        return msg(key).replace("{player}", value).replace("{value}", value).replace("{count}", value);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!sender.hasPermission("nonethm.admin")) {
            sender.sendMessage(msg("no-permission"));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {

            // ─── /nonethm bypass <player> ────────────────────────────────────
            case "bypass" -> {
                if (args.length < 2) { sender.sendMessage(colorize("&cUsage: /nonethm bypass <player>")); return true; }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) { sender.sendMessage(resolve("player-not-found", "{player}", args[1])); return true; }

                boolean added = plugin.getBypassManager().grantBypass(target);
                if (added) {
                    sender.sendMessage(resolve("bypass-granted", "{player}", target.getName()));
                    target.sendMessage(colorize(plugin.getConfig().getString("messages.prefix", "") + "&aYou now have §2netherite bypass§a!").replace("&", "§"));
                } else {
                    sender.sendMessage(resolve("already-bypassed", "{player}", target.getName()));
                }
            }

            // ─── /nonethm unbypass <player> ─────────────────────────────────
            case "unbypass" -> {
                if (args.length < 2) { sender.sendMessage(colorize("&cUsage: /nonethm unbypass <player>")); return true; }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) { sender.sendMessage(resolve("player-not-found", "{player}", args[1])); return true; }

                boolean removed = plugin.getBypassManager().revokeBypass(target);
                if (removed) {
                    sender.sendMessage(resolve("bypass-revoked", "{player}", target.getName()));
                    target.sendMessage(colorize(plugin.getConfig().getString("messages.prefix", "") + "&cYour netherite bypass has been &4revoked&c.").replace("&", "§"));
                    // Immediately scan and convert their inventory
                    new org.bukkit.scheduler.BukkitRunnable() {
                        @Override public void run() {
                            if (target.isOnline()) {
                                // trigger listener manually via a fake join-style scan
                                plugin.getServer().getPluginManager().callEvent(new org.bukkit.event.player.PlayerJoinEvent(target, null));
                            }
                        }
                    }.runTaskLater(plugin, 1L);
                } else {
                    sender.sendMessage(resolve("not-bypassed", "{player}", target.getName()));
                }
            }

            // ─── /nonethm banitem ────────────────────────────────────────────
            case "banitem" -> {
                plugin.getConfig().set("netherite-banned", true);
                plugin.saveConfig();
                sender.sendMessage(msg("netherite-banned"));
            }

            // ─── /nonethm unbanitem ──────────────────────────────────────────
            case "unbanitem" -> {
                plugin.getConfig().set("netherite-banned", false);
                plugin.saveConfig();
                sender.sendMessage(msg("netherite-unbanned"));
            }

            // ─── /nonethm reload ─────────────────────────────────────────────
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(msg("reload"));
            }

            // ─── /nonethm status ─────────────────────────────────────────────
            case "status" -> {
                boolean blocked = plugin.getConfig().getBoolean("netherite-blocked", true);
                boolean banned  = plugin.getConfig().getBoolean("netherite-banned", false);
                int     count   = plugin.getBypassManager().getBypassCount();

                sender.sendMessage(colorize(msgRaw("status-header")));
                sender.sendMessage(colorize(plugin.getConfig().getString("messages.status-blocked", "")
                        .replace("{value}", blocked ? "§aYES" : "§cNO").replace("&", "§")));
                sender.sendMessage(colorize(plugin.getConfig().getString("messages.status-banned", "")
                        .replace("{value}", banned ? "§4YES" : "§aNo").replace("&", "§")));
                sender.sendMessage(colorize(plugin.getConfig().getString("messages.status-bypassed-count", "")
                        .replace("{count}", String.valueOf(count)).replace("&", "§")));
            }

            // ─── /nonethm help ───────────────────────────────────────────────
            case "help" -> sendHelp(sender);

            default -> sendHelp(sender);
        }

        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(colorize("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(colorize("     &4&lNoNethM &8| &7Commands"));
        sender.sendMessage(colorize("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(colorize("&c/nonethm bypass &7<player>   &8» &fGive bypass to a player"));
        sender.sendMessage(colorize("&c/nonethm unbypass &7<player> &8» &fRemove bypass from a player"));
        sender.sendMessage(colorize("&c/nonethm banitem             &8» &fBan netherite entirely (deleted on pickup)"));
        sender.sendMessage(colorize("&c/nonethm unbanitem           &8» &fLift netherite ban (back to convert mode)"));
        sender.sendMessage(colorize("&c/nonethm status              &8» &fShow current plugin status"));
        sender.sendMessage(colorize("&c/nonethm reload              &8» &fReload config.yml"));
        sender.sendMessage(colorize("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(colorize("&7Default: Netherite &cblocked &7for ALL players."));
        sender.sendMessage(colorize("&7Bypass players keep their netherite gear."));
        sender.sendMessage(colorize("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    }
}
