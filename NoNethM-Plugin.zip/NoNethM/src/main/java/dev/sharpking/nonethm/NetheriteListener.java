package dev.sharpking.nonethm;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitRunnable;

public class NetheriteListener implements Listener {

    private final NoNethM plugin;

    public NetheriteListener(NoNethM plugin) {
        this.plugin = plugin;
    }

    // ─── Helpers ────────────────────────────────────────────────────────────────

    private boolean isBlocked() {
        return plugin.getConfig().getBoolean("netherite-blocked", true);
    }

    private boolean isBanned() {
        return plugin.getConfig().getBoolean("netherite-banned", false);
    }

    private String msg(String key) {
        String prefix = plugin.getConfig().getString("messages.prefix", "[NoNethM] ");
        String raw = plugin.getConfig().getString("messages." + key, "");
        return colorize(prefix + raw);
    }

    private String colorize(String s) {
        return s.replace("&", "§");
    }

    /**
     * Scans the player's entire inventory (including armor + offhand) and converts
     * or removes any netherite items depending on mode.
     */
    private void scanAndFix(Player player) {
        if (plugin.getBypassManager().isBypassed(player)) return;

        PlayerInventory inv = player.getInventory();
        boolean notified = false;

        // Check all 41 slots (0-35 main, 36-39 armor, 40 offhand)
        for (int i = 0; i < 41; i++) {
            ItemStack item = inv.getItem(i);
            if (item == null) continue;

            if (plugin.getConverter().isNetherite(item)) {
                if (isBanned()) {
                    // Remove entirely
                    inv.setItem(i, null);
                    if (!notified) {
                        player.sendMessage(msg("banned-pickup"));
                        notified = true;
                    }
                } else if (isBlocked()) {
                    // Convert to diamond equivalent
                    inv.setItem(i, plugin.getConverter().convert(item));
                    if (!notified) {
                        player.sendMessage(msg("converted"));
                        notified = true;
                    }
                }
            }
        }
    }

    // ─── Events ─────────────────────────────────────────────────────────────────

    /** Runs a deferred scan after any inventory click (equip, move, etc.) */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        runDeferred(player);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        runDeferred(player);
    }

    /** Player picks up a netherite item from the ground */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (plugin.getBypassManager().isBypassed(player)) return;

        ItemStack item = event.getItem().getItemStack();
        if (!plugin.getConverter().isNetherite(item)) return;

        if (isBanned()) {
            event.setCancelled(true);
            player.sendMessage(msg("banned-pickup"));
        } else if (isBlocked()) {
            // Let them pick it up, but convert immediately after
            runDeferred(player);
        }
    }

    /** Player switches hotbar slot */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onItemHeld(PlayerItemHeldEvent event) {
        runDeferred(event.getPlayer());
    }

    /** Player crafts something — cancel if result is netherite */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (plugin.getBypassManager().isBypassed(player)) return;
        if (!isBlocked() && !isBanned()) return;

        ItemStack result = event.getRecipe().getResult();
        if (plugin.getConverter().isNetherite(result)) {
            if (isBanned()) {
                event.setCancelled(true);
                player.sendMessage(msg("banned-pickup"));
            } else {
                // Allow craft but convert in inventory immediately after
                runDeferred(player);
            }
        }
    }

    /** Player joins — scan their inventory in case they logged out with netherite */
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        runDeferred(event.getPlayer());
    }

    // ─── Deferred scan (next tick) ───────────────────────────────────────────────

    private void runDeferred(Player player) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (player.isOnline()) scanAndFix(player);
            }
        }.runTaskLater(plugin, 1L);
    }
}
