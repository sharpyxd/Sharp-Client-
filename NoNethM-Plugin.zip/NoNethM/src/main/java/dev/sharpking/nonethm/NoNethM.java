package dev.sharpking.nonethm;

import org.bukkit.plugin.java.JavaPlugin;

public class NoNethM extends JavaPlugin {

    private static NoNethM instance;
    private BypassManager bypassManager;
    private NetheriteConverter converter;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        bypassManager = new BypassManager(this);
        converter = new NetheriteConverter(this);

        getServer().getPluginManager().registerEvents(new NetheriteListener(this), this);
        getCommand("nonethm").setExecutor(new NoNethMCommand(this));
        getCommand("nonethm").setTabCompleter(new NoNethMTabCompleter());

        printBanner();
    }

    @Override
    public void onDisable() {
        bypassManager.save();
        getLogger().info("NoNethM disabled.");
    }

    private void printBanner() {
        getLogger().info("§c╔══════════════════════════╗");
        getLogger().info("§c║   §4NoNethM §c- by §4SharpKingYT §c║");
        getLogger().info("§c║   §7Netherite blocked by default  §c║");
        getLogger().info("§c╚══════════════════════════╝");
    }

    public static NoNethM getInstance() { return instance; }
    public BypassManager getBypassManager() { return bypassManager; }
    public NetheriteConverter getConverter() { return converter; }
}
