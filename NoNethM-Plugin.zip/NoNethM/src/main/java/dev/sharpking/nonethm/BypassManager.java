package dev.sharpking.nonethm;

import org.bukkit.entity.Player;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class BypassManager {

    private final NoNethM plugin;
    private final Set<UUID> bypassedPlayers = new HashSet<>();

    public BypassManager(NoNethM plugin) {
        this.plugin = plugin;
        load();
    }

    private void load() {
        List<String> uuids = plugin.getConfig().getStringList("bypassed-players");
        for (String s : uuids) {
            try { bypassedPlayers.add(UUID.fromString(s)); } catch (Exception ignored) {}
        }
    }

    public void save() {
        List<String> uuids = bypassedPlayers.stream().map(UUID::toString).toList();
        plugin.getConfig().set("bypassed-players", uuids);
        plugin.saveConfig();
    }

    public boolean isBypassed(Player player) {
        return bypassedPlayers.contains(player.getUniqueId());
    }

    public boolean grantBypass(Player player) {
        boolean added = bypassedPlayers.add(player.getUniqueId());
        if (added) save();
        return added;
    }

    public boolean revokeBypass(Player player) {
        boolean removed = bypassedPlayers.remove(player.getUniqueId());
        if (removed) save();
        return removed;
    }

    public int getBypassCount() {
        return bypassedPlayers.size();
    }

    public Set<UUID> getBypassed() {
        return bypassedPlayers;
    }
}
